:HL["/_next/static/css/b00fc1b93ccc989e.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}},"staleTime":300,"buildId":"_DhiImqPuZHo_VZscl86x"}

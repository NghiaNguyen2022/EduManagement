var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/feed/[id]/comments/route.js")
R.c("server/chunks/[root-of-the-server]__0z7cu9w._.js")
R.c("server/chunks/_07hykws._.js")
R.c("server/chunks/[root-of-the-server]__10o.cg-._.js")
R.c("server/chunks/_next-internal_server_app_api_feed_[id]_comments_route_actions_0bt~si-.js")
R.m(30299)
module.exports=R.m(30299).exports

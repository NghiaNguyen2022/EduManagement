var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/app-portal/[slug]/reviews/route.js")
R.c("server/chunks/[root-of-the-server]__0j6c603._.js")
R.c("server/chunks/_07hykws._.js")
R.c("server/chunks/[root-of-the-server]__10o.cg-._.js")
R.c("server/chunks/_next-internal_server_app_api_app-portal_[slug]_reviews_route_actions_0fcek3..js")
R.m(98692)
module.exports=R.m(98692).exports

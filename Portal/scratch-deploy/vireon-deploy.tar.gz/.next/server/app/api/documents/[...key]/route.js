var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/documents/[...key]/route.js")
R.c("server/chunks/[root-of-the-server]__0da7ois._.js")
R.c("server/chunks/[root-of-the-server]__10o.cg-._.js")
R.c("server/chunks/_next-internal_server_app_api_documents_[___key]_route_actions_106f-vv.js")
R.m(78700)
module.exports=R.m(78700).exports

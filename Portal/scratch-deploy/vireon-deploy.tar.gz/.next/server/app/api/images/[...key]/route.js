var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/images/[...key]/route.js")
R.c("server/chunks/[root-of-the-server]__07662ue._.js")
R.c("server/chunks/[root-of-the-server]__10o.cg-._.js")
R.c("server/chunks/_next-internal_server_app_api_images_[___key]_route_actions_0ncsu.x.js")
R.m(10305)
module.exports=R.m(10305).exports

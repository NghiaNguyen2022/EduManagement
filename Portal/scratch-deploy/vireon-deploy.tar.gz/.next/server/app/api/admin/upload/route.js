var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/upload/route.js")
R.c("server/chunks/[root-of-the-server]__05d315h._.js")
R.c("server/chunks/_10mvahy._.js")
R.c("server/chunks/_07hykws._.js")
R.c("server/chunks/[root-of-the-server]__10o.cg-._.js")
R.c("server/chunks/0bl2_next_dist_0tiq-6c._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_upload_route_actions_09lqgkb.js")
R.m(17630)
module.exports=R.m(17630).exports

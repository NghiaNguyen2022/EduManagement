var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/setup/route.js")
R.c("server/chunks/[root-of-the-server]__02h3oml._.js")
R.c("server/chunks/_10mvahy._.js")
R.c("server/chunks/[root-of-the-server]__10o.cg-._.js")
R.c("server/chunks/_07hykws._.js")
R.c("server/chunks/0bl2_next_dist_0tiq-6c._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_setup_route_actions_06m3tf2.js")
R.m(60624)
module.exports=R.m(60624).exports

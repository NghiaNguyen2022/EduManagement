var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/reviews/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0jlxtaz._.js")
R.c("server/chunks/_10mvahy._.js")
R.c("server/chunks/[root-of-the-server]__10o.cg-._.js")
R.c("server/chunks/_07hykws._.js")
R.c("server/chunks/0bl2_next_dist_0tiq-6c._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_reviews_[id]_route_actions_0xowc1m.js")
R.m(5055)
module.exports=R.m(5055).exports

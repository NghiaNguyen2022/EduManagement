var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/app-portal/[slug]/documents/[docId]/route.js")
R.c("server/chunks/[root-of-the-server]__0h2-.xd._.js")
R.c("server/chunks/_10mvahy._.js")
R.c("server/chunks/[root-of-the-server]__10o.cg-._.js")
R.c("server/chunks/_07hykws._.js")
R.c("server/chunks/0bl2_next_dist_0tiq-6c._.js")
R.c("server/chunks/0zjb_server_app_api_admin_app-portal_[slug]_documents_[docId]_route_actions_0ul66z5.js")
R.m(33337)
module.exports=R.m(33337).exports

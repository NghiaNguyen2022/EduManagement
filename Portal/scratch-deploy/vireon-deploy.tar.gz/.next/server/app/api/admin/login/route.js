var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/login/route.js")
R.c("server/chunks/[root-of-the-server]__0b.5sfy._.js")
R.c("server/chunks/_10mvahy._.js")
R.c("server/chunks/[root-of-the-server]__10o.cg-._.js")
R.c("server/chunks/_07hykws._.js")
R.c("server/chunks/0bl2_next_dist_0tiq-6c._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_login_route_actions_0o428.q.js")
R.m(83089)
module.exports=R.m(83089).exports

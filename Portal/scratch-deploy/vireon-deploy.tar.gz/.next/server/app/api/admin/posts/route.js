var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/posts/route.js")
R.c("server/chunks/[root-of-the-server]__0b2yoc4._.js")
R.c("server/chunks/_10mvahy._.js")
R.c("server/chunks/0bl2_next_dist_0tiq-6c._.js")
R.c("server/chunks/_07hykws._.js")
R.c("server/chunks/[root-of-the-server]__10o.cg-._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_posts_route_actions_0ajmib5.js")
R.m(66127)
module.exports=R.m(66127).exports

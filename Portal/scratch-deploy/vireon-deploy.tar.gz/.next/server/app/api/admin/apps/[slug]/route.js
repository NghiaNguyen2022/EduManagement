var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/apps/[slug]/route.js")
R.c("server/chunks/[root-of-the-server]__12q1zh2._.js")
R.c("server/chunks/_10mvahy._.js")
R.c("server/chunks/[root-of-the-server]__10o.cg-._.js")
R.c("server/chunks/_07hykws._.js")
R.c("server/chunks/0bl2_next_dist_0tiq-6c._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_apps_[slug]_route_actions_0gq47bu.js")
R.m(37476)
module.exports=R.m(37476).exports

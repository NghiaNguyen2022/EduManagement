var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/app-portal/[slug]/video/route.js")
R.c("server/chunks/[root-of-the-server]__0qdvb91._.js")
R.c("server/chunks/_10mvahy._.js")
R.c("server/chunks/0bl2_next_dist_0tiq-6c._.js")
R.c("server/chunks/_07hykws._.js")
R.c("server/chunks/[root-of-the-server]__10o.cg-._.js")
R.c("server/chunks/0zjb_server_app_api_admin_app-portal_[slug]_video_route_actions_0tb~.-_.js")
R.m(20466)
module.exports=R.m(20466).exports

var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__0nilfm2._.js")
R.c("server/chunks/_0pfcw53._.js")
R.c("server/chunks/_07hykws._.js")
R.c("server/chunks/[root-of-the-server]__10o.cg-._.js")
R.c("server/chunks/0bl2_next_dist_0tiq-6c._.js")
R.c("server/chunks/_next-internal_server_app_sitemap_xml_route_actions_036gxb_.js")
R.m(62684)
module.exports=R.m(62684).exports

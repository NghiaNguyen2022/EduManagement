globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/DDyQZ0DpcWg1IM4SBv0xK/_buildManifest.js",
    "static/DDyQZ0DpcWg1IM4SBv0xK/_ssgManifest.js",
    "static/DDyQZ0DpcWg1IM4SBv0xK/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/05myhy1kjji5p.js",
    "static/chunks/0lriqkhzw77ht.js",
    "static/chunks/17u9997hacmtp.js",
    "static/chunks/10mplx1qo1yfm.js",
    "static/chunks/turbopack-0bb7n--kk9b~q.js"
  ]
};

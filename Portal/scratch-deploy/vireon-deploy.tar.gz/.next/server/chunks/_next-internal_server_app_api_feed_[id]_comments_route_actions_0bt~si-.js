module.exports=[21061,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_feed_%5Bid%5D_comments_route_actions_0bt~si-.js.map
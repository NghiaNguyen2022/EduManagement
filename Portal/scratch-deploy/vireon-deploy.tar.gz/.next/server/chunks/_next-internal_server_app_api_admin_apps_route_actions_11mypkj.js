module.exports=[42986,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_apps_route_actions_11mypkj.js.map
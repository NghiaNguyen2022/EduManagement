module.exports=[11603,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_app-portal_%5Bslug%5D_reviews_route_actions_0fcek3..js.map
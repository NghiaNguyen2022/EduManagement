module.exports=[94649,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_feed_%5Bid%5D_page_actions_0-r9g6a.js.map
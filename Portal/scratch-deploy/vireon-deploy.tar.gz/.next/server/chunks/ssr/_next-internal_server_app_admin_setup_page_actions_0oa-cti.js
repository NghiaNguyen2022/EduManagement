module.exports=[32971,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_admin_setup_page_actions_0oa-cti.js.map
module.exports=[96407,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_app-portal_%5Bslug%5D_page_actions_00ejqqt.js.map
module.exports=[36806,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_app-portal_page_actions_07kjzbw.js.map
module.exports=[81921,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_admin_posts_%5Bid%5D_edit_page_actions_0gbpj2p.js.map
module.exports=[95456,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_documents_%5B___key%5D_route_actions_106f-vv.js.map
module.exports=[5555,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_apps_%5Bslug%5D_route_actions_0gq47bu.js.map
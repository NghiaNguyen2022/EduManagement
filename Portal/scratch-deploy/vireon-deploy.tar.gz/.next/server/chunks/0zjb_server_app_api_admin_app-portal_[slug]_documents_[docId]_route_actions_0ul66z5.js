module.exports=[20766,s=>{"use strict";s.s([])}];

//# sourceMappingURL=0zjb_server_app_api_admin_app-portal_%5Bslug%5D_documents_%5BdocId%5D_route_actions_0ul66z5.js.map
globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/x74X3L-OIDbY7LN9UnQrC/_buildManifest.js",
    "static/x74X3L-OIDbY7LN9UnQrC/_ssgManifest.js",
    "static/x74X3L-OIDbY7LN9UnQrC/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0p8tu7idk~nwx.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/0y35dw7fjz2k2.js",
    "static/chunks/026ax.peyzfvk.js",
    "static/chunks/turbopack-01k1e0-bp2l4w.js"
  ]
};

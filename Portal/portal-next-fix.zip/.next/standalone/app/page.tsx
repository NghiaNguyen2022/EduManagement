import Link from "next/link";
import { listPublishedPosts, type Post } from "@/lib/store/posts";
import { toPlainExcerpt } from "@/lib/markdown";
import { apps } from "@/lib/apps-data";
import { CONTACT_EMAIL, CONTACT_ZALO_PHONE_DISPLAY, CONTACT_ZALO_URL } from "@/lib/site-config";
import { getRatingSummary } from "@/lib/store/reviews";
import { formatStars } from "@/lib/ratings";
import { listComments } from "@/lib/store/comments";
import SiteHeader from "./components/SiteHeader";

const fallbackNews: BlogPost[] = [
      {
            date: "30.07.2026",
            category: "ERP & Ngân hàng",
            title: "Tích hợp ERP với Ngân hàng (eBanking): Tự động hoá thanh toán & đối soát công nợ",
            summary:
                  "Tích hợp ERP với eBanking giúp doanh nghiệp tự động hoá thanh toán, giảm nhập liệu thủ công và chuẩn hoá quy trình đối soát.",
            href: "https://paul-digitalhub.com/wp/index.php/chuyen-doi-so/erp/tich-hop-erp-voi-ngan-hang-ebanking/",
            imageUrl: null,
      },
      {
            date: "24.07.2026",
            category: "ERP & Dữ liệu",
            title: "Master Data không phải việc riêng của IT",
            summary:
                  "Dữ liệu gốc cần người chịu trách nhiệm rõ ràng để ERP vận hành nhất quán và đáng tin cậy.",
            href: "https://paul-digitalhub.com/wp/index.php/chuyen-doi-so/erp/master-data-khong-phai-viec-rieng-cua-it/",
            imageUrl: null,
      },
      {
            date: "17.07.2026",
            category: "BI & Quản trị",
            title: "Dashboard không nên bắt đầu từ biểu đồ",
            summary:
                  "Một dashboard hiệu quả nên bắt đầu từ câu hỏi quản trị và quyết định mà doanh nghiệp cần đưa ra.",
            href: "https://paul-digitalhub.com/wp/index.php/chuyen-doi-so/dashboard-bat-dau-tu-cau-hoi-quan-tri/",
            imageUrl: null,
      },
      {
            date: "15.07.2026",
            category: "ERP & Vận hành",
            title: "Quản lý hạn sử dụng sau khi mở bao bì trong ERP và SAP B1",
            summary:
                  "Bài toán kiểm soát hạn dùng liên quan trực tiếp đến kho, sản xuất, chất lượng và dữ liệu ERP.",
            href: "https://paul-digitalhub.com/wp/index.php/common/quan-ly-han-su-dung-sau-khi-mo-bao-bi-erp-sap-b1/",
            imageUrl: null,
      },
      {
            date: "17.06.2026",
            category: "SAP Business One",
            title: "Hành trình chuẩn hóa SAP Business One cho nhà máy sản xuất",
            summary:
                  "Từ các yêu cầu nhỏ đến một giai đoạn chuẩn hóa costing, tài chính và dữ liệu vận hành.",
            href: "https://paul-digitalhub.com/wp/index.php/chuyen-doi-so/sap-business-one-phase-2-nha-may-san-xuat-costing/",
            imageUrl: null,
      },
      {
            date: "25.05.2026",
            category: "Quy trình ERP",
            title: "Quy trình bán hàng thanh toán trước trên SAP Business One",
            summary:
                  "Luồng vận hành từ đơn bán hàng, nhận tiền, giao hàng đến hóa đơn và đối trừ công nợ.",
            href: "https://paul-digitalhub.com/wp/index.php/chuyen-doi-so/erp/quy-trinh-ban-hang-thanh-toan-truoc-sap-business-one/",
            imageUrl: null,
      },
];

type BlogPost = {
      date: string;
      category: string;
      title: string;
      summary: string;
      href: string;
      imageUrl: string | null;
};

async function getDigitalSpacePosts(): Promise<Post[]> {
      try {
            return (await listPublishedPosts()).slice(0, 3);
      } catch {
            return [];
      }
}

async function getAppRatingSummaries(): Promise<
      Map<string, { average: number; count: number }>
> {
      const detailApps = apps.filter((app) => app.hasDetailPage);
      const entries = await Promise.all(
            detailApps.map(async (app) => {
                  try {
                        return [app.slug, await getRatingSummary(app.slug)] as const;
                  } catch {
                        return [app.slug, { average: 0, count: 0 }] as const;
                  }
            }),
      );
      return new Map(entries);
}

async function getCommentCounts(posts: Post[]): Promise<Map<string, number>> {
      const entries = await Promise.all(
            posts.map(async (post) => {
                  try {
                        return [post.id, (await listComments(post.id)).length] as const;
                  } catch {
                        return [post.id, 0] as const;
                  }
            }),
      );
      return new Map(entries);
}

function formatSpaceDate(value: string) {
      return new Intl.DateTimeFormat("vi-VN", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
      })
            .format(new Date(value))
            .replace(/\//g, ".");
}

type WordPressPost = {
      date: string;
      link: string;
      title: { rendered: string };
      excerpt: { rendered: string };
};

const WORDPRESS_POSTS_URL =
      "https://paul-digitalhub.com/wp/index.php?rest_route=/wp/v2/posts&per_page=6&_fields=date,link,title,excerpt";

function extractFirstImage(html: string): string | null {
      const match = html.match(/<img[^>]+src="([^"]+)"/);
      return match ? match[1] : null;
}

function cleanWordPressText(value: string) {
      return value
            .replace(/<[^>]*>/g, " ")
            .replace(/&nbsp;/g, " ")
            .replace(/&#8211;|&ndash;/g, "–")
            .replace(/&#8212;|&mdash;/g, "—")
            .replace(/&#038;|&amp;/g, "&")
            .replace(/&quot;|&#8220;|&#8221;/g, '"')
            .replace(/&#8216;|&#8217;/g, "'")
            .replace(/\s+/g, " ")
            .trim();
}

function formatPostDate(value: string) {
      return new Intl.DateTimeFormat("vi-VN", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
      })
            .format(new Date(value))
            .replace(/\//g, ".");
}

async function getLatestPosts(): Promise<BlogPost[]> {
      try {
            const response = await fetch(WORDPRESS_POSTS_URL, {
                  next: { revalidate: 10800 },
            });

            if (!response.ok) {
                  return fallbackNews;
            }

            const posts = (await response.json()) as WordPressPost[];

            return posts.slice(0, 6).map((post) => {
                  const summary = cleanWordPressText(post.excerpt.rendered);

                  return {
                        date: formatPostDate(post.date),
                        category: "Paul Digital Hub",
                        title: cleanWordPressText(post.title.rendered),
                        summary:
                              summary.length > 180 ? `${summary.slice(0, 177).trim()}…` : summary,
                        href: post.link,
                        imageUrl: extractFirstImage(post.excerpt.rendered),
                  };
            });
      } catch {
            return fallbackNews;
      }
}

const channels = [
      {
            code: "Za",
            title: "Zalo",
            description: `Chat trực tiếp qua Zalo (${CONTACT_ZALO_PHONE_DISPLAY}) để được tư vấn nhanh.`,
            href: CONTACT_ZALO_URL,
      },
      {
            code: "@",
            title: "Email",
            description: `Gửi email tới ${CONTACT_EMAIL} để được hỗ trợ.`,
            href: `mailto:${CONTACT_EMAIL}`,
      },
      {
            code: "YT",
            title: "YouTube",
            description: "Video hướng dẫn kỹ thuật, ERP, dữ liệu và giải pháp vận hành.",
            href: "https://www.youtube.com/@Technical_Solution_ERP",
      },
      {
            code: "in",
            title: "LinkedIn",
            description: "Kết nối chuyên môn và theo dõi các chia sẻ về chuyển đổi số.",
            href: "https://www.linkedin.com/in/nghia-nguyen-790108139/",
      },
      {
            code: "f",
            title: "Facebook",
            description: "Kết nối và cập nhật các hoạt động, nội dung chia sẻ mới.",
            href: "https://www.facebook.com/nghia.nguyennhuu.3",
      },
];

export default async function Home() {
      const news = await getLatestPosts();
      const spacePosts = await getDigitalSpacePosts();
      const [ratingSummaries, commentCounts] = await Promise.all([
            getAppRatingSummaries(),
            getCommentCounts(spacePosts),
      ]);

      return (
            <main>
                  <SiteHeader
                        eyebrow="Digital workspace"
                        brandHref="#top"
                        links={[
                              { href: "#applications", label: "Ứng dụng" },
                              { href: "#space", label: "Không gian số" },
                              { href: "#about", label: "Giới thiệu" },
                              { href: "#news", label: "Bài viết" },
                              { href: "#connect", label: "Kết nối" },
                        ]}
                        ctaHref="https://paul-digitalhub.com/wp/"
                        ctaLabel="Paul Digital Hub"
                  />

                  <section className="hero" id="top">
                        <div className="hero-copy">
                              <p className="kicker">Một điểm đến. Nhiều giải pháp.</p>
                              <h1>
                                    Không gian số cho
                                    <span> công việc tốt hơn.</span>
                              </h1>
                              <p className="hero-lead">
                                    Cổng truy cập tập trung tới các ứng dụng quản lý, nội dung chuyên
                                    môn và những sản phẩm số được xây dựng từ nhu cầu vận hành thực tế.
                              </p>
                              <div className="hero-actions">
                                    <a className="button button-primary" href="#applications">
                                          Khám phá ứng dụng
                                    </a>
                                    <a className="button button-quiet" href="#about">
                                          Về Vireon
                                    </a>
                              </div>
                              <div className="hero-meta">
                                    <span>Thiết kế thực dụng</span>
                                    <span>Dữ liệu liền mạch</span>
                                    <span>Sẵn sàng mở rộng</span>
                              </div>
                        </div>
                        <div className="hero-visual" aria-hidden="true">
                              <div className="orbit orbit-one" />
                              <div className="orbit orbit-two" />
                              <div className="visual-card visual-card-main">
                                    <span className="visual-label">Vireon Portal</span>
                                    <strong>Ứng dụng và tri thức, trong một không gian.</strong>
                                    <div className="visual-line">
                                          <i />
                                          <i />
                                          <i />
                                    </div>
                              </div>
                              <div className="visual-card visual-card-small">
                                    <span>02</span>
                                    <small>Ứng dụng đang vận hành</small>
                              </div>
                              <div className="visual-dot dot-one" />
                              <div className="visual-dot dot-two" />
                        </div>
                  </section>

                  <section className="section applications" id="applications">
                        <div className="section-heading">
                              <div>
                                    <p className="kicker">Application hub</p>
                                    <h2>Trung tâm ứng dụng Vireon</h2>
                              </div>
                              <p>
                                    Một điểm truy cập chung để người dùng tìm đúng công cụ nhanh chóng.
                                    Ứng dụng mới có thể được bổ sung mà không làm thay đổi cấu trúc tổng thể.
                              </p>
                        </div>
                        <div className="hub-summary" aria-label="Tổng quan trung tâm ứng dụng">
                              <span><strong>02</strong> ứng dụng đang vận hành</span>
                              <span><strong>01</strong> vị trí sẵn sàng mở rộng</span>
                              <span><strong>01</strong> cổng truy cập thống nhất</span>
                              <Link className="hub-summary-link" href="/app-portal">
                                    Xem App Portal ↗
                              </Link>
                        </div>
                        <div className="app-grid">
                              {apps.map((app) => {
                                    const summary = ratingSummaries.get(app.slug);
                                    const displayRating =
                                          summary && summary.count > 0 ? summary.average : app.baseRating;

                                    return (
                                    <article className={`app-card ${app.tone}`} key={app.slug}>
                                          <div className="app-top">
                                                <span className="app-icon">{app.code}</span>
                                                <span className="app-status">{app.eyebrow}</span>
                                          </div>
                                          <h3>{app.title}</h3>
                                          <p>{app.description}</p>
                                          {app.hasDetailPage && (
                                                <div className="app-rating-row">
                                                      <span className="review-stars">
                                                            {formatStars(displayRating ?? 0)}
                                                      </span>
                                                      <span className="app-rating-count">
                                                            {displayRating
                                                                  ? `${displayRating.toFixed(1)}/5${
                                                                        summary && summary.count > 0
                                                                              ? ` · ${summary.count} đánh giá`
                                                                              : ""
                                                                  }`
                                                                  : "Chưa có đánh giá"}
                                                      </span>
                                                </div>
                                          )}
                                          <div className="app-actions">
                                                <a
                                                      className="app-action-primary"
                                                      href={app.href}
                                                      target={app.href.startsWith("http") ? "_blank" : undefined}
                                                      rel={app.href.startsWith("http") ? "noopener noreferrer" : undefined}
                                                >
                                                      {app.action} <span aria-hidden="true">↗</span>
                                                </a>
                                                {app.hasDetailPage && (
                                                      <Link
                                                            className="app-action-secondary"
                                                            href={`/app-portal/${app.slug}`}
                                                      >
                                                            Xem chi tiết
                                                      </Link>
                                                )}
                                          </div>
                                    </article>
                                    );
                              })}
                        </div>
                  </section>

                  <section className="section space" id="space">
                        <div className="section-heading">
                              <div>
                                    <p className="kicker">Không gian số Vireon</p>
                                    <h2>Ghi chú &amp; chia sẻ ngắn</h2>
                              </div>
                              <Link className="text-link" href="/feed">
                                    Xem tất cả ↗
                              </Link>
                        </div>
                        {spacePosts.length === 0 ? (
                              <p className="admin-empty">
                                    Chưa có bài viết nào được đăng. Nội dung sẽ xuất hiện tại đây khi
                                    quản trị viên đăng bài mới.
                              </p>
                        ) : (
                              <div className="space-grid">
                                    {spacePosts.map((post) => (
                                          <Link className="space-card" href={`/feed/${post.id}`} key={post.id}>
                                                {post.coverImageKey && (
                                                      // eslint-disable-next-line @next/next/no-img-element
                                                      <img
                                                            className="space-card-cover"
                                                            src={`/api/images/${post.coverImageKey}`}
                                                            alt=""
                                                      />
                                                )}
                                                <div className="space-card-body">
                                                      <div className="space-card-meta">
                                                            <time>{formatSpaceDate(post.createdAt)}</time>
                                                            <span className="comment-badge">
                                                                  💬 {commentCounts.get(post.id) ?? 0} bình luận
                                                            </span>
                                                      </div>
                                                      <h3>{post.title}</h3>
                                                      <p>{toPlainExcerpt(post.body)}</p>
                                                      {post.tags.length > 0 && (
                                                            <div className="tag-row">
                                                                  {post.tags.map((tag) => (
                                                                        <span className="tag-chip" key={tag}>
                                                                              {tag}
                                                                        </span>
                                                                  ))}
                                                            </div>
                                                      )}
                                                </div>
                                          </Link>
                                    ))}
                              </div>
                        )}
                  </section>

                  <section className="section about" id="about">
                        <div className="about-statement">
                              <p className="kicker">Người xây dựng Vireon</p>
                              <h2>
                                    Nghĩa Nguyễn
                                    <span> (Paul)</span>
                              </h2>
                              <p className="about-role">ERP · Business Intelligence · Chuyển đổi số</p>
                              <div className="about-stats">
                                    <div>
                                          <strong>10+</strong>
                                          <span>năm kinh nghiệm ERP &amp; BI</span>
                                    </div>
                                    <div>
                                          <strong>02</strong>
                                          <span>ứng dụng Vireon đang vận hành</span>
                                    </div>
                                    <div>
                                          <strong>01</strong>
                                          <span>hub kiến thức — Paul Digital Hub</span>
                                    </div>
                              </div>
                        </div>
                        <div className="about-content">
                              <p>
                                    Hơn 10 năm tư vấn và triển khai <strong>ERP</strong>,{" "}
                                    <strong>Business Intelligence</strong> và{" "}
                                    <strong>chuyển đổi số</strong> cho doanh nghiệp, tôi xây dựng Vireon
                                    để giải đúng bài toán vận hành thực tế: hiểu quy trình, chuẩn hóa dữ
                                    liệu và tạo ra trải nghiệm đủ đơn giản để mọi người dùng được ngay.
                              </p>
                              <p>
                                    Song song đó, tôi chia sẻ kiến thức chuyên môn về ERP, BI và chuyển
                                    đổi số tại <strong>Paul Digital Hub</strong> — nền tảng kết nối công
                                    nghệ, dữ liệu và con người do tôi sáng lập.
                              </p>
                              <div className="about-links">
                                    <a
                                          href="https://paul-digitalhub.com/wp/"
                                          target="_blank"
                                          rel="noopener noreferrer"
                                    >
                                          Paul Digital Hub ↗
                                    </a>
                                    <a
                                          href="https://hoinhapkynguyenso.blogspot.com/p/paul-nghia-erp-consultant-leader.html"
                                          target="_blank"
                                          rel="noopener noreferrer"
                                    >
                                          Hồ sơ chi tiết ↗
                                    </a>
                              </div>
                        </div>
                  </section>

                  <section className="section news" id="news">
                        <div className="section-heading">
                              <div>
                                    <p className="kicker">Từ Paul Digital Hub</p>
                                    <h2>Bài viết mới nhất</h2>
                              </div>
                              <a
                                    className="text-link"
                                    href="https://paul-digitalhub.com/wp/"
                                    target="_blank"
                                    rel="noopener noreferrer"
                              >
                                    Xem tất cả bài viết ↗
                              </a>
                        </div>
                        <div className="news-grid">
                              {news.map((item, index) => (
                                    <article className="news-card" key={item.href}>
                                          {item.imageUrl && (
                                                // eslint-disable-next-line @next/next/no-img-element
                                                <img className="news-card-cover" src={item.imageUrl} alt="" />
                                          )}
                                          <div className="news-index">{String(index + 1).padStart(2, "0")}</div>
                                          <div className="news-meta">
                                                <span>{item.category}</span>
                                                <time>{item.date}</time>
                                          </div>
                                          <h3>{item.title}</h3>
                                          <p>{item.summary}</p>
                                          <a href={item.href} target="_blank" rel="noopener noreferrer">
                                                Đọc bài viết ↗
                                          </a>
                                    </article>
                              ))}
                        </div>
                  </section>

                  <section className="section connect" id="connect">
                        <div className="section-heading">
                              <div>
                                    <p className="kicker">Kết nối</p>
                                    <h2>Theo dõi trên các kênh</h2>
                              </div>
                              <p>
                                    Nội dung được chia sẻ theo từng định dạng: bài viết chuyên sâu,
                                    video hướng dẫn và cập nhật hoạt động chuyên môn.
                              </p>
                        </div>
                        <div className="channel-grid">
                              {channels.map((channel) => (
                                    <a
                                          className="channel-card"
                                          href={channel.href}
                                          target="_blank"
                                          rel="noopener noreferrer"
                                          key={channel.title}
                                    >
                                          <span className="channel-icon">{channel.code}</span>
                                          <span>
                                                <strong>{channel.title}</strong>
                                                <small>{channel.description}</small>
                                          </span>
                                          <i aria-hidden="true">↗</i>
                                    </a>
                              ))}
                        </div>
                  </section>

                  <section className="section roadmap" id="roadmap">
                        <p className="kicker">Hệ sinh thái mở</p>
                        <h2>Một portal có thể lớn lên cùng các sản phẩm mới.</h2>
                        <p>
                              Cấu trúc hub được chuẩn bị để bổ sung ứng dụng, tài liệu và chương
                              trình hợp tác mới mà vẫn giữ trải nghiệm truy cập đơn giản, nhất quán.
                        </p>
                        <a className="button button-light" href="#connect">
                              Kết nối và trao đổi
                        </a>
                  </section>

                  <footer>
                        <div className="footer-brand">
                              <span className="brand-mark">V</span>
                              <div>
                                    <strong>Vireon</strong>
                                    <p>Ứng dụng số được xây dựng từ công việc thật.</p>
                              </div>
                        </div>
                        <div className="footer-links">
                              <div>
                                    <span>Khám phá</span>
                                    <a href="#applications">Trung tâm ứng dụng</a>
                                    <a href="#news">Bài viết mới</a>
                                    <Link href="/feed">Không gian số</Link>
                              </div>
                              <div>
                                    <span>Kết nối</span>
                                    <a href="https://paul-digitalhub.com/wp/" target="_blank" rel="noopener noreferrer">Paul Digital Hub</a>
                                    <a href="https://www.youtube.com/@Technical_Solution_ERP" target="_blank" rel="noopener noreferrer">YouTube</a>
                                    <a href="https://www.linkedin.com/in/nghia-nguyen-790108139/" target="_blank" rel="noopener noreferrer">LinkedIn</a>
                                    <a href="https://www.facebook.com/nghia.nguyennhuu.3" target="_blank" rel="noopener noreferrer">Facebook</a>
                              </div>
                        </div>
                        <div className="footer-bottom">
                              <span>© 2026 Vireon. All rights reserved.</span>
                              <a href="#top">Lên đầu trang ↑</a>
                        </div>
                  </footer>
            </main>
      );
}

import Link from "next/link";
import type { Metadata } from "next";
import { apps } from "@/lib/apps-data";
import { getRatingSummary } from "@/lib/store/reviews";
import { formatStars } from "@/lib/ratings";
import SiteHeader from "../components/SiteHeader";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "App Portal",
  description:
    "Khám phá từng ứng dụng của Vireon, xem khách hàng tiêu biểu và đánh giá thực tế từ người dùng.",
  alternates: { canonical: "/app-portal" },
  openGraph: {
    type: "website",
    title: "App Portal | Vireon",
    description:
      "Khám phá từng ứng dụng của Vireon, xem khách hàng tiêu biểu và đánh giá thực tế từ người dùng.",
    url: "/app-portal",
  },
};

async function getSummaries(): Promise<Map<string, { average: number; count: number }>> {
  const detailApps = apps.filter((app) => app.hasDetailPage);
  const entries = await Promise.all(
    detailApps.map(async (app) => {
      try {
        return [app.slug, await getRatingSummary(app.slug)] as const;
      } catch {
        return [app.slug, { average: 0, count: 0 }] as const;
      }
    }),
  );
  return new Map(entries);
}

export default async function AppPortalPage() {
  const summaries = await getSummaries();
  const detailApps = apps.filter((app) => app.hasDetailPage);
  const totalCustomers = detailApps.reduce((sum, app) => sum + app.customers.length, 0);
  const totalReviews = Array.from(summaries.values()).reduce((sum, s) => sum + s.count, 0);

  return (
    <main>
      <SiteHeader
        eyebrow="App Portal"
        links={[
          { href: "/", label: "Trang chủ" },
          { href: "/feed", label: "Không gian số" },
        ]}
      />

      <section className="section applications">
        <div className="section-heading">
          <div>
            <p className="kicker">App Portal</p>
            <h1>Toàn bộ ứng dụng Vireon</h1>
          </div>
          <p>
            Khám phá từng ứng dụng, xem khách hàng tiêu biểu và đánh giá thực tế
            từ người dùng.
          </p>
        </div>

        <div className="hub-summary" aria-label="Tổng quan App Portal">
          <span>
            <strong>{String(detailApps.length).padStart(2, "0")}</strong> ứng dụng đang vận hành
          </span>
          <span>
            <strong>{String(totalCustomers).padStart(2, "0")}</strong> khách hàng tiêu biểu
          </span>
          <span>
            <strong>{String(totalReviews).padStart(2, "0")}</strong> đánh giá từ người dùng
          </span>
        </div>

        <div className="app-grid">
          {apps.map((app) => {
            const summary = summaries.get(app.slug);
            const displayRating = summary && summary.count > 0 ? summary.average : app.baseRating;

            return (
              <article className={`app-card ${app.tone}`} key={app.slug}>
                <div className="app-top">
                  <span className="app-icon">{app.code}</span>
                  <span className="app-status">{app.eyebrow}</span>
                </div>
                <h3>{app.title}</h3>
                <p>{app.description}</p>

                {app.hasDetailPage && (
                  <div className="app-rating-row">
                    <span className="review-stars">{formatStars(displayRating ?? 0)}</span>
                    <span className="app-rating-count">
                      {displayRating
                        ? `${displayRating.toFixed(1)}/5${
                            summary && summary.count > 0 ? ` · ${summary.count} đánh giá` : ""
                          }`
                        : "Chưa có đánh giá"}
                    </span>
                  </div>
                )}

                <div className="app-actions">
                  <a
                    className="app-action-primary"
                    href={app.href}
                    target={app.href.startsWith("http") ? "_blank" : undefined}
                    rel={app.href.startsWith("http") ? "noopener noreferrer" : undefined}
                  >
                    {app.action} <span aria-hidden="true">↗</span>
                  </a>
                  {app.hasDetailPage && (
                    <Link className="app-action-secondary" href={`/app-portal/${app.slug}`}>
                      Xem chi tiết
                    </Link>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      </section>
    </main>
  );
}

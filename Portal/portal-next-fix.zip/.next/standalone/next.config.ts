import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  async rewrites() {
    return [{ source: "/applications", destination: "/app-portal" }];
  },
};

export default nextConfig;

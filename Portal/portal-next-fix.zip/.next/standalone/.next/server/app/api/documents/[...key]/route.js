var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/documents/[...key]/route.js")
R.c("server/chunks/[root-of-the-server]__0pt-1d-._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_documents_[___key]_route_actions_106f-vv.js")
R.m(62569)
module.exports=R.m(62569).exports

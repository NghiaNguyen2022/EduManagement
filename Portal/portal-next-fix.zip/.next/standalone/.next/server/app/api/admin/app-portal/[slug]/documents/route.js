var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/app-portal/[slug]/documents/route.js")
R.c("server/chunks/[root-of-the-server]__10fs~w_._.js")
R.c("server/chunks/_0olmoa1._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/_0rai1d3._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/0zjb_server_app_api_admin_app-portal_[slug]_documents_route_actions_0ckstmu.js")
R.m(27963)
module.exports=R.m(27963).exports

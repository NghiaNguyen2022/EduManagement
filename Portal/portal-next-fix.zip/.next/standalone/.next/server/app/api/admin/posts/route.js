var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/posts/route.js")
R.c("server/chunks/[root-of-the-server]__13-n83~._.js")
R.c("server/chunks/_0olmoa1._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/_0rai1d3._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_posts_route_actions_0ajmib5.js")
R.m(57213)
module.exports=R.m(57213).exports

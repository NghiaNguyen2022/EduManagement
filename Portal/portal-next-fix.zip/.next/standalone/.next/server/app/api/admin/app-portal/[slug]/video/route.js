var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/app-portal/[slug]/video/route.js")
R.c("server/chunks/[root-of-the-server]__00_8y-t._.js")
R.c("server/chunks/_0olmoa1._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/_0rai1d3._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/0zjb_server_app_api_admin_app-portal_[slug]_video_route_actions_0tb~.-_.js")
R.m(53581)
module.exports=R.m(53581).exports

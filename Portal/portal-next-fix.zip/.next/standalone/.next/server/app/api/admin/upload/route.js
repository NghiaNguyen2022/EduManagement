var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/upload/route.js")
R.c("server/chunks/[root-of-the-server]__0lpaxyj._.js")
R.c("server/chunks/_0olmoa1._.js")
R.c("server/chunks/_0rai1d3._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_upload_route_actions_09lqgkb.js")
R.m(65334)
module.exports=R.m(65334).exports

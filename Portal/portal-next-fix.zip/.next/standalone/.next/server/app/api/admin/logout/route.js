var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/logout/route.js")
R.c("server/chunks/[root-of-the-server]__0g6_k-x._.js")
R.c("server/chunks/_0olmoa1._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/_0rai1d3._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_logout_route_actions_0lmnpyx.js")
R.m(82494)
module.exports=R.m(82494).exports

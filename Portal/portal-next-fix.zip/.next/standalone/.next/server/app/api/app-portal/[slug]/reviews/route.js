var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/app-portal/[slug]/reviews/route.js")
R.c("server/chunks/[root-of-the-server]__0ufubnu._.js")
R.c("server/chunks/_0rai1d3._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_app-portal_[slug]_reviews_route_actions_0fcek3..js")
R.m(21422)
module.exports=R.m(21422).exports

var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/login/route.js")
R.c("server/chunks/[root-of-the-server]__040n7rd._.js")
R.c("server/chunks/_0olmoa1._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_0rai1d3._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_login_route_actions_0o428.q.js")
R.m(45543)
module.exports=R.m(45543).exports

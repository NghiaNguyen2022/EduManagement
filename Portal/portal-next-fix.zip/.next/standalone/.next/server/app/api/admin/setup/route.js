var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/setup/route.js")
R.c("server/chunks/[root-of-the-server]__0.9p3jh._.js")
R.c("server/chunks/_0olmoa1._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_0rai1d3._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_setup_route_actions_06m3tf2.js")
R.m(25360)
module.exports=R.m(25360).exports

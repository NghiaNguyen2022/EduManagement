var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/images/[...key]/route.js")
R.c("server/chunks/[root-of-the-server]__0u~wvgj._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_images_[___key]_route_actions_0ncsu.x.js")
R.m(10203)
module.exports=R.m(10203).exports

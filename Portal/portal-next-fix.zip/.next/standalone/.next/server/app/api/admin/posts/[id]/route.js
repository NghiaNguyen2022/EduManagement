var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/posts/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0fx75z0._.js")
R.c("server/chunks/_0olmoa1._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/_0rai1d3._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_posts_[id]_route_actions_0uraove.js")
R.m(13340)
module.exports=R.m(13340).exports

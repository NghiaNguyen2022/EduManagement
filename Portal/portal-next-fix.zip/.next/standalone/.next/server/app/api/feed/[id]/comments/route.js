var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/feed/[id]/comments/route.js")
R.c("server/chunks/[root-of-the-server]__119jx6k._.js")
R.c("server/chunks/_0rai1d3._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_feed_[id]_comments_route_actions_0bt~si-.js")
R.m(66990)
module.exports=R.m(66990).exports

var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/reviews/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0bn.50w._.js")
R.c("server/chunks/_0olmoa1._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_0rai1d3._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_reviews_[id]_route_actions_0xowc1m.js")
R.m(58914)
module.exports=R.m(58914).exports

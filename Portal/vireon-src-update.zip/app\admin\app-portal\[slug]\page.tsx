import Link from "next/link";
import { notFound } from "next/navigation";
import { requireAdmin } from "@/lib/auth/session";
import { getAppBySlug } from "@/lib/apps-data";
import { getAppContent } from "@/lib/store/app-content";
import VideoUrlForm from "../VideoUrlForm";
import DocumentManager from "../DocumentManager";

export const dynamic = "force-dynamic";

export default async function AdminAppContentPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  await requireAdmin();
  const { slug } = await params;
  const app = getAppBySlug(slug);
  if (!app) notFound();

  const content = await getAppContent(slug);

  return (
    <div className="admin-shell">
      <div className="admin-topbar">
        <h1>{app.title}</h1>
        <Link className="button-ghost" href="/admin/app-portal">
          ← Danh sách ứng dụng
        </Link>
      </div>

      <div className="admin-stack">
        <div className="admin-card">
          <h3>Video demo</h3>
          <p className="subtitle">Dán link YouTube hoặc Vimeo. Bỏ trống để ẩn video.</p>
          <VideoUrlForm slug={slug} initialUrl={content.demoVideoUrl} />
        </div>

        <div className="admin-card">
          <h3>Tài liệu giới thiệu</h3>
          <p className="subtitle">
            Khách truy cập có thể tải về từ trang chi tiết ứng dụng.
          </p>
          <DocumentManager slug={slug} documents={content.documents} />
        </div>
      </div>
    </div>
  );
}

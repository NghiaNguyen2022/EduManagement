"use client";

import { useState } from "react";

type Props = {
  appSlug: string;
};

export default function ReviewForm({ appSlug }: Props) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [website, setWebsite] = useState(""); // honeypot
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    setSubmitting(true);
    setError(null);

    try {
      const response = await fetch(`/api/app-portal/${appSlug}/reviews`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, phone, email, rating, comment, website }),
      });
      const data = await response.json();

      if (!response.ok) {
        setError(data.error ?? "Không thể gửi đánh giá.");
        return;
      }

      setSubmitted(true);
      setName("");
      setPhone("");
      setEmail("");
      setRating(5);
      setComment("");
    } catch {
      setError("Không thể kết nối máy chủ.");
    } finally {
      setSubmitting(false);
    }
  }

  if (submitted) {
    return (
      <div className="form-success">
        Cảm ơn bạn đã chia sẻ! Đánh giá sẽ hiển thị công khai sau khi được kiểm duyệt.
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit}>
      {error && <div className="form-error">{error}</div>}

      <div className="star-picker" role="radiogroup" aria-label="Chọn số sao đánh giá">
        {[1, 2, 3, 4, 5].map((value) => (
          <button
            key={value}
            type="button"
            className={value <= rating ? "active" : ""}
            aria-label={`${value} sao`}
            aria-pressed={value === rating}
            onClick={() => setRating(value)}
          >
            {value <= rating ? "★" : "☆"}
          </button>
        ))}
      </div>

      <div className="form-field">
        <label htmlFor="review-name">Tên của bạn</label>
        <input
          id="review-name"
          value={name}
          onChange={(event) => setName(event.target.value)}
          required
        />
      </div>

      <div className="form-field">
        <label htmlFor="review-phone">Số điện thoại (không bắt buộc)</label>
        <input id="review-phone" value={phone} onChange={(event) => setPhone(event.target.value)} />
      </div>

      <div className="form-field">
        <label htmlFor="review-email">Email (không bắt buộc)</label>
        <input
          id="review-email"
          type="email"
          value={email}
          onChange={(event) => setEmail(event.target.value)}
        />
      </div>

      <div className="form-field">
        <label htmlFor="review-comment">Bình luận</label>
        <textarea
          id="review-comment"
          value={comment}
          onChange={(event) => setComment(event.target.value)}
          required
        />
      </div>

      <div className="honeypot-field" aria-hidden="true">
        <label htmlFor="review-website">Website</label>
        <input
          id="review-website"
          tabIndex={-1}
          autoComplete="off"
          value={website}
          onChange={(event) => setWebsite(event.target.value)}
        />
      </div>

      <button className="button-submit" type="submit" disabled={submitting}>
        {submitting ? "Đang gửi..." : "Gửi đánh giá"}
      </button>
    </form>
  );
}

import { CONTACT_EMAIL, CONTACT_ZALO_PHONE_DISPLAY, CONTACT_ZALO_URL } from "./site-config";

export type Channel = {
  code: string;
  title: string;
  description: string;
  href: string;
};

export const channels: Channel[] = [
  {
    code: "Za",
    title: "Zalo",
    description: `Chat trực tiếp qua Zalo (${CONTACT_ZALO_PHONE_DISPLAY}) để được tư vấn nhanh.`,
    href: CONTACT_ZALO_URL,
  },
  {
    code: "@",
    title: "Email",
    description: `Gửi email tới ${CONTACT_EMAIL} để được hỗ trợ.`,
    href: `mailto:${CONTACT_EMAIL}`,
  },
  {
    code: "YT",
    title: "YouTube",
    description: "Video hướng dẫn kỹ thuật, ERP, dữ liệu và giải pháp vận hành.",
    href: "https://www.youtube.com/@Technical_Solution_ERP",
  },
  {
    code: "in",
    title: "LinkedIn",
    description: "Kết nối chuyên môn và theo dõi các chia sẻ về chuyển đổi số.",
    href: "https://www.linkedin.com/in/nghia-nguyen-790108139/",
  },
  {
    code: "f",
    title: "Facebook",
    description: "Kết nối và cập nhật các hoạt động, nội dung chia sẻ mới.",
    href: "https://www.facebook.com/nghia.nguyennhuu.3",
  },
];

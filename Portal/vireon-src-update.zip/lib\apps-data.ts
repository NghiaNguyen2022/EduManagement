export type AppTone = "blue" | "amber" | "slate";

export type AppCustomer = {
  name: string;
  role: string;
};

export type AppInfo = {
  slug: string;
  code: string;
  eyebrow: string;
  title: string;
  description: string;
  longDescription: string;
  href: string;
  action: string;
  tone: AppTone;
  hasDetailPage: boolean;
  highlights: string[];
  customers: AppCustomer[];
  baseRating: number | null;
};

// Static catalog: this app list stays hand-edited in code rather than
// admin-managed, since the marketing copy changes rarely and is reviewed
// alongside the rest of the site. Customer names below are placeholders
// until real case studies are supplied.
export const apps: AppInfo[] = [
  {
    slug: "eduman",
    code: "EDU",
    eyebrow: "Đang vận hành",
    title: "Quản lý trường học",
    description:
      "Nền tảng quản lý tuyển sinh, học vụ, giáo viên, tài chính và kết nối phụ huynh.",
    longDescription:
      "Hệ thống quản lý trường học tập trung, giúp ban giám hiệu và phòng ban vận hành tuyển sinh, học vụ, nhân sự giáo viên và tài chính trên cùng một nền tảng, đồng thời giữ liên lạc thông suốt với phụ huynh.",
    href: "https://vireon.vn/app-portal/edu-management",
    action: "Mở ứng dụng",
    tone: "blue",
    hasDetailPage: true,
    highlights: [
      "Quản lý tuyển sinh và hồ sơ học sinh tập trung",
      "Theo dõi học vụ, điểm số và thời khóa biểu",
      "Quản lý nhân sự giáo viên và bảng lương",
      "Cổng thông tin kết nối phụ huynh theo thời gian thực",
    ],
    customers: [
      { name: "Trường TH-THCS Minh Khai", role: "Trường phổ thông liên cấp" },
      { name: "Hệ thống giáo dục Ánh Dương", role: "Chuỗi trường mầm non - tiểu học" },
      { name: "Trường THPT Nguyễn Trãi", role: "Trường trung học phổ thông" },
    ],
    baseRating: 4.6,
  },
  {
    slug: "residenceman",
    code: "RC",
    eyebrow: "Đang vận hành",
    title: "Quản lý lưu xá",
    description:
      "Số hóa hồ sơ lưu trú, sinh hoạt, kỷ luật và công tác quản lý lưu xá.",
    longDescription:
      "Số hóa toàn bộ nghiệp vụ quản lý lưu xá: hồ sơ lưu trú, theo dõi sinh hoạt nội trú, xử lý kỷ luật và báo cáo vận hành cho ban quản lý ký túc xá, lưu xá sinh viên.",
    href: "https://vireon.vn/app-portal/residence-management",
    action: "Mở ứng dụng",
    tone: "amber",
    hasDetailPage: true,
    highlights: [
      "Quản lý hồ sơ lưu trú và phân bổ phòng ở",
      "Theo dõi sinh hoạt và điểm danh nội trú",
      "Ghi nhận và xử lý kỷ luật minh bạch",
      "Báo cáo vận hành lưu xá theo thời gian thực",
    ],
    customers: [
      { name: "Ký túc xá Đại học Kinh tế", role: "Ký túc xá sinh viên" },
      { name: "Lưu xá Nữ sinh Hòa Bình", role: "Lưu xá nội trú" },
    ],
    baseRating: 4.4,
  },
  {
    slug: "coming-soon",
    code: "+",
    eyebrow: "Sẵn sàng mở rộng",
    title: "Ứng dụng tiếp theo",
    description:
      "Các công cụ số mới sẽ được bổ sung vào hub theo nhu cầu vận hành thực tế.",
    longDescription: "",
    href: "#roadmap",
    action: "Xem định hướng",
    tone: "slate",
    hasDetailPage: false,
    highlights: [],
    customers: [],
    baseRating: null,
  },
];

export function getAppBySlug(slug: string): AppInfo | undefined {
  return apps.find((app) => app.slug === slug && app.hasDetailPage);
}

import Link from "next/link";
import { requireAdmin } from "@/lib/auth/session";
import { apps } from "@/lib/apps-data";

export const dynamic = "force-dynamic";

export default async function AdminAppPortalPage() {
  await requireAdmin();
  const detailApps = apps.filter((app) => app.hasDetailPage);

  return (
    <div className="admin-shell">
      <div className="admin-topbar">
        <h1>App Portal — Video &amp; tài liệu</h1>
        <Link className="button-ghost" href="/admin">
          ← Bảng điều khiển
        </Link>
      </div>

      <div className="admin-card">
        <table className="admin-table">
          <thead>
            <tr>
              <th>Ứng dụng</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {detailApps.map((app) => (
              <tr key={app.slug}>
                <td>{app.title}</td>
                <td className="actions">
                  <Link className="button-ghost" href={`/admin/app-portal/${app.slug}`}>
                    Quản lý nội dung
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

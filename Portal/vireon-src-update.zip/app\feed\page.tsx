import Link from "next/link";
import type { Metadata } from "next";
import { listAllTags, listPublishedPosts, type Post } from "@/lib/store/posts";
import { toPlainExcerpt } from "@/lib/markdown";
import { SITE_NAV } from "@/lib/nav";
import SiteHeader from "../components/SiteHeader";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Không gian số",
  description: "Nơi chia sẻ kiến thức, ghi chú ngắn và cập nhật từ đội ngũ Vireon.",
  alternates: { canonical: "/feed" },
  openGraph: {
    type: "website",
    title: "Không gian số | Vireon",
    description: "Nơi chia sẻ kiến thức, ghi chú ngắn và cập nhật từ đội ngũ Vireon.",
    url: "/feed",
  },
};

function formatDate(value: string) {
  return new Intl.DateTimeFormat("vi-VN", { day: "2-digit", month: "2-digit", year: "numeric" })
    .format(new Date(value))
    .replace(/\//g, ".");
}

async function getFeedData(tag?: string): Promise<{ posts: Post[]; tags: string[] }> {
  try {
    const [posts, tags] = await Promise.all([listPublishedPosts(tag), listAllTags()]);
    return { posts, tags };
  } catch {
    return { posts: [], tags: [] };
  }
}

export default async function FeedPage({
  searchParams,
}: {
  searchParams: Promise<{ tag?: string }>;
}) {
  const { tag } = await searchParams;
  const { posts, tags } = await getFeedData(tag);

  return (
    <main>
      <SiteHeader eyebrow="Không gian số" links={SITE_NAV} />

      <section className="section space">
        <div className="section-heading">
          <div>
            <p className="kicker">Không gian số</p>
            <h1>Bài viết &amp; chia sẻ nội bộ</h1>
          </div>
          <p>
            Nơi chia sẻ kiến thức, ghi chú ngắn và cập nhật từ đội ngũ Vireon.
          </p>
        </div>

        {tags.length > 0 && (
          <div className="feed-filters">
            <Link className={!tag ? "active" : ""} href="/feed">
              Tất cả
            </Link>
            {tags.map((item) => (
              <Link
                key={item}
                className={tag === item ? "active" : ""}
                href={`/feed?tag=${encodeURIComponent(item)}`}
              >
                {item}
              </Link>
            ))}
          </div>
        )}

        {posts.length === 0 ? (
          <p className="admin-empty">Chưa có bài viết nào được xuất bản.</p>
        ) : (
          <div className="space-grid">
            {posts.map((post) => (
              <Link className="space-card" href={`/feed/${post.id}`} key={post.id}>
                {post.coverImageKey && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    className="space-card-cover"
                    src={`/api/images/${post.coverImageKey}`}
                    alt=""
                  />
                )}
                <div className="space-card-body">
                  <time>{formatDate(post.createdAt)}</time>
                  <h3>{post.title}</h3>
                  <p>{toPlainExcerpt(post.body)}</p>
                  {post.tags.length > 0 && (
                    <div className="tag-row">
                      {post.tags.map((item) => (
                        <span className="tag-chip" key={item}>
                          {item}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </Link>
            ))}
          </div>
        )}

        <p>
          <Link className="text-link" href="/">
            ← Về trang chủ Vireon
          </Link>
        </p>
      </section>
    </main>
  );
}

import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  experimental: {
    cpus: 1,
  },
  outputFileTracingExcludes: {
    "*": [
      "cpanel-bundle/**",
      "build/**",
      "dist/**",
      "drizzle/**",
      "examples/**",
      "worker/**",
      "tests/**",
      "*.zip",
    ],
  },
};

export default nextConfig;

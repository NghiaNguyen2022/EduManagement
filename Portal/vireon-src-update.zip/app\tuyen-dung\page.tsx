import Link from "next/link";
import type { Metadata } from "next";
import { CONTACT_EMAIL } from "@/lib/site-config";
import { SITE_NAV } from "@/lib/nav";
import SiteHeader from "../components/SiteHeader";

export const metadata: Metadata = {
  title: "Tuyển dụng",
  description: "Cơ hội nghề nghiệp tại Vireon — ERP, Business Intelligence và phát triển sản phẩm số.",
  alternates: { canonical: "/tuyen-dung" },
  openGraph: {
    type: "website",
    title: "Tuyển dụng | Vireon",
    description: "Cơ hội nghề nghiệp tại Vireon — ERP, Business Intelligence và phát triển sản phẩm số.",
    url: "/tuyen-dung",
  },
};

export default function CareersPage() {
  return (
    <main>
      <SiteHeader eyebrow="Tuyển dụng" links={SITE_NAV} />

      <section className="section careers">
        <div className="section-heading">
          <div>
            <p className="kicker">Cơ hội nghề nghiệp</p>
            <h1>Tuyển dụng tại Vireon</h1>
          </div>
          <p>
            Chúng tôi tìm kiếm những người muốn xây dựng ứng dụng và giải pháp
            dữ liệu thực sự được dùng, không chỉ để trình diễn.
          </p>
        </div>

        <div className="careers-empty">
          <p className="careers-empty-title">Hiện chưa có vị trí tuyển dụng</p>
          <p>
            Vireon chưa mở đợt tuyển dụng chính thức nào. Nếu bạn quan tâm đến
            ERP, Business Intelligence hoặc phát triển sản phẩm số, hãy gửi hồ
            sơ giới thiệu — chúng tôi sẽ liên hệ khi có vị trí phù hợp.
          </p>
          <a className="button button-primary" href={`mailto:${CONTACT_EMAIL}`}>
            Gửi hồ sơ qua email
          </a>
        </div>

        <p>
          <Link className="text-link" href="/">
            ← Về trang chủ Vireon
          </Link>
        </p>
      </section>
    </main>
  );
}

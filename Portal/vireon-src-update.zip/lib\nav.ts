export type NavLink = {
  href: string;
  label: string;
};

// Used on the homepage itself: pure hash anchors so SiteHeader renders a
// native <a> (this runtime's next/link does not scroll for hash-only hrefs).
export const HOME_NAV: NavLink[] = [
  { href: "#about", label: "Giới thiệu" },
  { href: "#applications", label: "Ứng dụng" },
  { href: "/feed", label: "Không gian số" },
  { href: "/app-portal", label: "App Portal" },
  { href: "/tuyen-dung", label: "Tuyển dụng" },
  { href: "/lien-he", label: "Liên hệ" },
];

// Used on every other page: path + hash so it navigates to the homepage
// first, then scrolls to the section.
export const SITE_NAV: NavLink[] = [
  { href: "/#about", label: "Giới thiệu" },
  { href: "/#applications", label: "Ứng dụng" },
  { href: "/feed", label: "Không gian số" },
  { href: "/app-portal", label: "App Portal" },
  { href: "/tuyen-dung", label: "Tuyển dụng" },
  { href: "/lien-he", label: "Liên hệ" },
];

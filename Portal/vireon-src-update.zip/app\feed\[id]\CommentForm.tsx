"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

type Props = {
  postId: string;
};

export default function CommentForm({ postId }: Props) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [comment, setComment] = useState("");
  const [website, setWebsite] = useState(""); // honeypot
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    setSubmitting(true);
    setError(null);

    try {
      const response = await fetch(`/api/feed/${postId}/comments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, comment, website }),
      });
      const data = await response.json();

      if (!response.ok) {
        setError(data.error ?? "Không thể gửi bình luận.");
        return;
      }

      setName("");
      setComment("");
      router.refresh();
    } catch {
      setError("Không thể kết nối máy chủ.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      {error && <div className="form-error">{error}</div>}

      <div className="form-field">
        <label htmlFor="comment-name">Tên của bạn</label>
        <input
          id="comment-name"
          value={name}
          onChange={(event) => setName(event.target.value)}
          required
        />
      </div>

      <div className="form-field">
        <label htmlFor="comment-body">Bình luận</label>
        <textarea
          id="comment-body"
          value={comment}
          onChange={(event) => setComment(event.target.value)}
          required
        />
      </div>

      <div className="honeypot-field" aria-hidden="true">
        <label htmlFor="comment-website">Website</label>
        <input
          id="comment-website"
          tabIndex={-1}
          autoComplete="off"
          value={website}
          onChange={(event) => setWebsite(event.target.value)}
        />
      </div>

      <button className="button-submit" type="submit" disabled={submitting}>
        {submitting ? "Đang gửi..." : "Gửi bình luận"}
      </button>
    </form>
  );
}

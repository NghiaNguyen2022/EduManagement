import Link from "next/link";
import type { Metadata } from "next";
import { channels } from "@/lib/channels";
import { SITE_NAV } from "@/lib/nav";
import SiteHeader from "../components/SiteHeader";

export const metadata: Metadata = {
  title: "Liên hệ",
  description: "Kết nối với Vireon qua Zalo, email hoặc các kênh mạng xã hội.",
  alternates: { canonical: "/lien-he" },
  openGraph: {
    type: "website",
    title: "Liên hệ | Vireon",
    description: "Kết nối với Vireon qua Zalo, email hoặc các kênh mạng xã hội.",
    url: "/lien-he",
  },
};

export default function ContactPage() {
  return (
    <main>
      <SiteHeader eyebrow="Liên hệ" links={SITE_NAV} />

      <section className="section connect">
        <div className="section-heading">
          <div>
            <p className="kicker">Liên hệ</p>
            <h1>Kết nối với Vireon</h1>
          </div>
          <p>
            Trao đổi về ứng dụng, hợp tác hoặc góp ý — chọn kênh phù hợp nhất
            với bạn bên dưới.
          </p>
        </div>

        <div className="channel-grid">
          {channels.map((channel) => (
            <a
              className="channel-card"
              href={channel.href}
              target="_blank"
              rel="noopener noreferrer"
              key={channel.title}
            >
              <span className="channel-icon">{channel.code}</span>
              <span>
                <strong>{channel.title}</strong>
                <small>{channel.description}</small>
              </span>
              <i aria-hidden="true">↗</i>
            </a>
          ))}
        </div>

        <p>
          <Link className="text-link" href="/">
            ← Về trang chủ Vireon
          </Link>
        </p>
      </section>
    </main>
  );
}

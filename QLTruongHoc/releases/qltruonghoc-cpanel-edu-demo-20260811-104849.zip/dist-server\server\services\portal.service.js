import { listBuoiHocDaHocThieuBaoGiang } from "../db/baoGiang.repository.js";
import { listDanhGiaByHocSinh } from "../db/danhGia.repository.js";
import { listDiemDanhGanDayByHocSinh } from "../db/diemDanh.repository.js";
import { findDonViById } from "../db/donVi.repository.js";
import { findGiaoVienByNguoiDungId } from "../db/giaoVien.repository.js";
import { listEnrollmentsByHocSinh, listLopHocByGiaoVienId, } from "../db/lopHoc.repository.js";
import { listHoatDongByLopHoc } from "../db/hoatDong.repository.js";
import { listPhuHuynhByNguoiDungId, listHocSinhByPhuHuynhId } from "../db/phuHuynh.repository.js";
import { listSucKhoeByHocSinh } from "../db/sucKhoe.repository.js";
import { listKhoanPhaiThuByHocSinh } from "../db/taiChinh.repository.js";
import { listThanhTichByHocSinh } from "../db/thanhTich.repository.js";
import { countTraoDoiGanDayTheoLop } from "../db/traoDoi.repository.js";
import { listDonXinPhepByHocSinhIds } from "../db/xinPhep.repository.js";
import { listThoiKhoaBieu } from "./lichHoc.service.js";
import { listTraoDoi } from "./traoDoi.service.js";
function todayIso() {
    return new Date().toISOString().slice(0, 10);
}
function addDaysIso(iso, days) {
    const date = new Date(`${iso}T00:00:00Z`);
    date.setUTCDate(date.getUTCDate() + days);
    return date.toISOString().slice(0, 10);
}
export async function getTeacherPortalOverview(input) {
    const teacher = await findGiaoVienByNguoiDungId(input.donViId, input.userId);
    if (!teacher) {
        throw new Error("Tài khoản giáo viên chưa được liên kết với hồ sơ giáo viên tại đơn vị này.");
    }
    const today = todayIso();
    const [assignments, sessions] = await Promise.all([
        listLopHocByGiaoVienId(teacher.id),
        listThoiKhoaBieu({
            donViId: input.donViId,
            tuNgay: today,
            denNgay: addDaysIso(today, 7),
            giaoVienId: teacher.id,
        }),
    ]);
    const lopHocIds = assignments.map((item) => item.lopHoc.id);
    // Buổi đã dạy trong 7 ngày qua nhưng chưa ghi báo giảng — nhắc giáo viên bổ
    // sung, chỉ tính trên các lớp giáo viên này đang phụ trách.
    const [baoGiangThieu, traoDoiGanDay] = await Promise.all([
        listBuoiHocDaHocThieuBaoGiang({
            lopHocIds,
            tuNgay: addDaysIso(today, -7),
            denNgay: today,
        }),
        countTraoDoiGanDayTheoLop(lopHocIds, `${addDaysIso(today, -7)} 00:00:00`),
    ]);
    return {
        teacher,
        classes: assignments.map((item) => ({
            assignment: item.phanCong,
            class: item.lopHoc,
        })),
        sessions,
        sessionsHomNay: sessions.filter((item) => item.buoiHoc.ngayHoc === today).length,
        baoGiangChoNhap: baoGiangThieu.length,
        traoDoiGanDay,
    };
}
/**
 * Tổng quan Portal phụ huynh. Không gắn với một đơn vị "đang chọn" cụ thể —
 * một phụ huynh có thể có con học ở nhiều đơn vị, nên trang tổng quan hiển
 * thị thông tin chung (không thiên vị đơn vị nào), còn việc quản lý chi tiết
 * theo từng đơn vị nằm trong `organizations` (xem `ParentPortalOrganizationGroup`
 * ở client).
 */
export async function getParentPortalOverview(input) {
    /**
     * Chủ đích: một phụ huynh có thể có con học ở nhiều đơn vị, hồ sơ được
     * dùng chung qua số điện thoại (xem `CrossOrgGuardianConfirmError` ở
     * `phuHuynh.service.ts`). Vì vậy Portal gộp dữ liệu từ MỌI hồ sơ
     * `PhuHuynh` gắn với tài khoản này, không chỉ đơn vị đang chọn/đơn vị
     * "đăng nhập mặc định" (thường là một đơn vị neo chung, ví dụ đơn vị hệ
     * thống — không mang ý nghĩa nghiệp vụ cho phụ huynh).
     *
     * Không cần kiểm thêm một lượt phân quyền theo từng đơn vị ở đây: mỗi
     * dòng `PhuHuynh.nguoiDungId` chỉ được gán bởi nhân viên có quyền
     * `hoc_sinh.quan_ly` qua `createGuardianAccount`, và mỗi liên kết học
     * sinh-phụ huynh khác đơn vị đã bắt buộc xác nhận rõ ràng qua
     * `CrossOrgGuardianConfirmError` (`addGuardianToStudent`) trước khi tạo.
     * Đó mới là điểm chốt quyền thực sự — "đơn vị đang chọn" của phụ huynh
     * chỉ là chỗ neo phiên đăng nhập, không phải căn cứ để lọc dữ liệu con.
     */
    const guardians = await listPhuHuynhByNguoiDungId(input.userId);
    if (guardians.length === 0) {
        throw new Error("Không tìm thấy hồ sơ phụ huynh trong hệ thống.");
    }
    const children = (await Promise.all(guardians.map(async (guardian) => {
        const parentOrganization = await findDonViById(guardian.donViId);
        const childRows = await listHocSinhByPhuHuynhId(guardian.id);
        const tuNgay = todayIso();
        const denNgay = addDaysIso(tuNgay, 14);
        const timetable = await listThoiKhoaBieu({
            donViId: guardian.donViId,
            tuNgay,
            denNgay,
        });
        return Promise.all(childRows.map(async (row) => {
            const childOrganization = row.hocSinh.donViId === guardian.donViId
                ? parentOrganization
                : await findDonViById(row.hocSinh.donViId);
            const enrollments = await listEnrollmentsByHocSinh(row.hocSinh.id);
            const activeEnrollments = enrollments.filter((enrollment) => enrollment.enrollment.trangThai === "dang_hoc" ||
                enrollment.enrollment.trangThai === "bao_luu");
            const lopHocIds = activeEnrollments.map((enrollment) => enrollment.lopHoc.id);
            const activeClasses = activeEnrollments.map((enrollment) => ({
                enrollmentId: enrollment.enrollment.id,
                ngayVaoLop: enrollment.enrollment.ngayVaoLop,
                ngayRoiLop: enrollment.enrollment.ngayRoiLop,
                trangThai: enrollment.enrollment.trangThai,
                lopHoc: {
                    id: enrollment.lopHoc.id,
                    maLop: enrollment.lopHoc.maLop,
                    tenLop: enrollment.lopHoc.tenLop,
                    phongHoc: enrollment.lopHoc.phongHoc,
                },
            }));
            const schedules = timetable
                .filter((item) => lopHocIds.includes(item.buoiHoc.lopHocId))
                .sort((left, right) => `${left.buoiHoc.ngayHoc} ${left.buoiHoc.gioBatDau}`.localeCompare(`${right.buoiHoc.ngayHoc} ${right.buoiHoc.gioBatDau}`))
                .slice(0, 8);
            // Chỉ xem — form ghi trao đổi mới vẫn dành cho giáo viên/học vụ ở
            // `/communications`, chưa mở cho phụ huynh tự ghi trong đợt này.
            // Lưu ý: `listTraoDoi` trả về dạng nested `{traoDoi, hocSinh, lopHoc,
            // nguoiTao, donVi}` (xem `TraoDoiRow`) — phải gỡ phẳng ra đây, không
            // dùng thẳng như dạng phẳng (đã có đúng lỗi này ở `traoDoiApi.ts`
            // phía client, xem PROJECT_SUMMARY.md).
            const traoDoi = (await listTraoDoi(row.hocSinh.donViId, undefined, {
                hocSinhId: row.hocSinh.id,
            }))
                .slice(0, 5)
                .map((item) => ({
                id: item.traoDoi.id,
                nguoiGuiVaiTro: item.traoDoi.nguoiGuiVaiTro,
                kenhLienLac: item.traoDoi.kenhLienLac,
                noiDung: item.traoDoi.noiDung,
                ketQua: item.traoDoi.ketQua,
                createdAt: item.traoDoi.createdAt,
                nguoiTao: item.nguoiTao,
            }));
            // Chỉ xem — số liệu đã có sẵn từ module Tài chính (H01-H09),
            // không tính toán lại ở đây.
            const khoanPhaiThu = (await listKhoanPhaiThuByHocSinh(row.hocSinh.id)).map((item) => ({
                id: item.khoanPhaiThu.id,
                tongTien: item.khoanPhaiThu.tongTien,
                giamTru: item.khoanPhaiThu.giamTru,
                daThu: item.khoanPhaiThu.daThu,
                trangThai: item.khoanPhaiThu.trangThai,
                tenKyThu: item.kyThu.tenKyThu,
            }));
            // F05: cảnh báo vắng học tự động, chỉ gộp đúng dữ liệu điểm danh
            // của học sinh này (không dùng ThongBao dùng chung — xem
            // docs/analysis/F03_F05_xin_phep_thong_bao_vang.md).
            const absenceRows = await listDiemDanhGanDayByHocSinh(row.hocSinh.id, addDaysIso(tuNgay, -30), tuNgay);
            const absences = absenceRows.map((item) => ({
                id: item.diemDanh.id,
                ngayHoc: item.ngayHoc,
                gioBatDau: item.gioBatDau,
                tenLop: item.tenLop,
                trangThai: item.diemDanh.trangThai,
            }));
            const absenceSummary = {
                unexcused: absences.filter((item) => item.trangThai === "vang_khong_phep").length,
            };
            // Chứng chỉ/thành tích + kết quả học tập — chỉ xem, ghi nhận vẫn
            // qua /api/hoc-sinh/:id/thanh-tich|danh-gia (quyền hoc_tap.ghi_nhan
            // cho giáo viên/học vụ). Phạm vi hiển thị đã được chốt đúng con qua
            // guardian linkage ở trên, không cần kiểm quyền hoc_tap thêm ở đây.
            const [thanhTichRows, danhGiaRows, sucKhoeRows] = await Promise.all([
                listThanhTichByHocSinh(row.hocSinh.id),
                listDanhGiaByHocSinh(row.hocSinh.id),
                listSucKhoeByHocSinh(row.hocSinh.id),
            ]);
            const thanhTich = thanhTichRows.map((item) => ({
                id: item.id,
                hocSinhId: item.hocSinhId,
                tenThanhTich: item.tenThanhTich,
                ketQua: item.ketQua,
                ngayDat: item.ngayDat,
                noiCap: item.noiCap,
                tepMinhChungUrl: item.tepMinhChungUrl,
                ghiChu: item.ghiChu,
                createdAt: item.createdAt,
            }));
            const danhGia = danhGiaRows.map((item) => ({
                id: item.danhGia.id,
                hocSinhId: item.danhGia.hocSinhId,
                enrollmentId: item.danhGia.enrollmentId,
                loaiDanhGia: item.danhGia.loaiDanhGia,
                linhVucPhatTrien: item.danhGia.linhVucPhatTrien,
                diemSo: item.danhGia.diemSo,
                xepLoai: item.danhGia.xepLoai,
                nhanXet: item.danhGia.nhanXet,
                ngayDanhGia: item.danhGia.ngayDanhGia,
                lopHoc: item.lopHoc,
            }));
            // Album ảnh hoạt động lớp — đúng (các) lớp con đang học hiện tại,
            // chỉ giữ hoạt động không gắn thẻ ai (cả lớp) hoặc gắn đúng con này.
            const hoatDong = (await Promise.all(lopHocIds.map((id) => listHoatDongByLopHoc(id))))
                .flat()
                .filter((item) => item.hocSinhIds.length === 0 || item.hocSinhIds.includes(row.hocSinh.id))
                .sort((a, b) => (a.hoatDong.ngayHoatDong < b.hoatDong.ngayHoatDong ? 1 : -1));
            // F03: đơn xin phép đã gửi cho con này — chỉ xem, gửi đơn mới qua
            // POST /api/xin-phep riêng (xem xinPhep.router.ts).
            const donXinPhep = (await listDonXinPhepByHocSinhIds([row.hocSinh.id])).map((item) => ({
                id: item.donXinPhep.id,
                lopHocId: item.donXinPhep.lopHocId,
                tenLop: item.lopHoc.tenLop,
                tuNgay: item.donXinPhep.tuNgay,
                denNgay: item.donXinPhep.denNgay,
                lyDo: item.donXinPhep.lyDo,
                trangThai: item.donXinPhep.trangThai,
                ghiChuDuyet: item.donXinPhep.ghiChuDuyet,
                createdAt: item.donXinPhep.createdAt,
            }));
            return {
                lienKet: row.lienKet,
                hocSinh: {
                    ...row.hocSinh,
                    donVi: childOrganization
                        ? {
                            id: childOrganization.id,
                            maDonVi: childOrganization.maDonVi,
                            tenDonVi: childOrganization.tenDonVi,
                        }
                        : undefined,
                },
                donVi: childOrganization
                    ? {
                        id: childOrganization.id,
                        maDonVi: childOrganization.maDonVi,
                        tenDonVi: childOrganization.tenDonVi,
                    }
                    : {
                        id: row.hocSinh.donViId,
                        maDonVi: `DV-${row.hocSinh.donViId}`,
                        tenDonVi: "Đơn vị chưa xác định",
                    },
                activeClasses,
                schedules,
                traoDoi,
                khoanPhaiThu,
                absences,
                absenceSummary,
                donXinPhep,
                thanhTich,
                danhGia,
                sucKhoe: sucKhoeRows,
                hoatDong,
            };
        }));
    }))).flat();
    const upcomingSessions = children
        .flatMap((child) => child.schedules.map((session) => ({
        childName: child.hocSinh.hoTen,
        childCode: child.hocSinh.maHocSinh,
        childOrganization: child.donVi,
        session,
    })))
        .sort((left, right) => `${left.session.buoiHoc.ngayHoc} ${left.session.buoiHoc.gioBatDau}`.localeCompare(`${right.session.buoiHoc.ngayHoc} ${right.session.buoiHoc.gioBatDau}`));
    // Nhóm quản lý chi tiết theo từng đơn vị — bao trọn cả 3 trường hợp: nhiều
    // con nhiều đơn vị (mỗi đơn vị một nhóm, có thể nhiều con trong nhóm), một
    // con nhiều đơn vị (mỗi đơn vị vẫn ra một nhóm riêng), nhiều con một đơn vị
    // (chỉ một nhóm duy nhất).
    const organizationsById = new Map();
    for (const child of children) {
        const key = child.donVi.id;
        const group = organizationsById.get(key);
        if (group) {
            group.children.push(child);
        }
        else {
            organizationsById.set(key, {
                donVi: child.donVi,
                children: [child],
                upcomingSessions: [],
            });
        }
    }
    for (const session of upcomingSessions) {
        organizationsById.get(session.childOrganization.id)?.upcomingSessions.push(session);
    }
    const organizations = Array.from(organizationsById.values()).sort((left, right) => left.donVi.tenDonVi.localeCompare(right.donVi.tenDonVi));
    // Thông tin phụ huynh hiển thị ở đầu trang là thông tin CHUNG của cùng một
    // người (nhiều dòng `PhuHuynh` ở các đơn vị khác nhau chỉ là hồ sơ của
    // cùng một tài khoản) — không gắn với đơn vị nào, nên không cần chọn theo
    // đơn vị đang thao tác, chỉ cần một hồ sơ đại diện để hiển thị.
    const representativeGuardian = guardians[0];
    return {
        parent: {
            id: representativeGuardian.id,
            hoTen: representativeGuardian.hoTen,
            maPhuHuynh: representativeGuardian.maPhuHuynh,
            dienThoai: representativeGuardian.dienThoai,
            email: representativeGuardian.email,
            ngheNghiep: representativeGuardian.ngheNghiep,
            diaChi: representativeGuardian.diaChi,
        },
        children,
        upcomingSessions: upcomingSessions.slice(0, 8),
        organizations,
    };
}

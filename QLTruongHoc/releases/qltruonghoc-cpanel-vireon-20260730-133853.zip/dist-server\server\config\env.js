import fs from "node:fs";
import path from "node:path";
import dotenv from "dotenv";
const projectRoot = process.cwd();
const envLocalPath = path.resolve(projectRoot, ".env.local");
const envPath = path.resolve(projectRoot, ".env");
if (fs.existsSync(envLocalPath)) {
    const result = dotenv.config({
        path: envLocalPath,
        override: true,
    });
    if (result.error) {
        throw new Error(`Không thể đọc .env.local: ${result.error.message}`);
    }
}
else if (fs.existsSync(envPath)) {
    const result = dotenv.config({
        path: envPath,
        override: false,
    });
    if (result.error) {
        throw new Error(`Không thể đọc .env: ${result.error.message}`);
    }
}
function getRequiredEnv(name) {
    const value = process.env[name]?.trim();
    if (!value) {
        throw new Error(`Thiếu biến môi trường bắt buộc: ${name}. ` +
            `Đã tìm cấu hình tại: ${envLocalPath}`);
    }
    return value;
}
function getPositiveIntegerEnv(name, fallback) {
    const rawValue = process.env[name]?.trim();
    if (!rawValue) {
        return fallback;
    }
    const value = Number(rawValue);
    if (!Number.isInteger(value) ||
        value <= 0) {
        throw new Error(`Biến môi trường ${name} phải là số nguyên dương.`);
    }
    return value;
}
function normalizeCookiePath(value) {
    const pathValue = value?.trim() || "/";
    const withLeadingSlash = pathValue.startsWith("/")
        ? pathValue
        : `/${pathValue}`;
    if (withLeadingSlash === "/") {
        return withLeadingSlash;
    }
    return withLeadingSlash.replace(/\/+$/, "");
}
export const env = {
    nodeEnv: process.env.NODE_ENV?.trim() ||
        "development",
    port: getPositiveIntegerEnv("PORT", 3100),
    host: process.env.HOST?.trim() ||
        "127.0.0.1",
    authCookieName: process.env.AUTH_COOKIE_NAME?.trim() ||
        "qlth_session",
    cookiePath: normalizeCookiePath(process.env.COOKIE_PATH),
    database: {
        host: getRequiredEnv("DATABASE_HOST"),
        port: getPositiveIntegerEnv("DATABASE_PORT", 3306),
        user: getRequiredEnv("DATABASE_USER"),
        password: getRequiredEnv("DATABASE_PASSWORD"),
        name: getRequiredEnv("DATABASE_NAME"),
        connectionLimit: getPositiveIntegerEnv("DATABASE_CONNECTION_LIMIT", 10),
    },
};
export const envPaths = {
    projectRoot,
    envLocalPath,
    envPath,
};

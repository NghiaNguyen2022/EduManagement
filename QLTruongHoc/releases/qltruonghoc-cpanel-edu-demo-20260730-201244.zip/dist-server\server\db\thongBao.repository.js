import { and, count, desc, eq, inArray, like, or } from "drizzle-orm";
import { donVi, thongBao, thongBaoDaDoc } from "../../drizzle/schema.js";
import { getDb } from "./connection.js";
import { toDatabaseDateTime } from "../utils/dateTime.js";
const now = toDatabaseDateTime;
export async function listThongBaoByDonVi(donViId, userId) {
    const db = getDb();
    return db
        .select({
        thongBao,
        daDocAt: thongBaoDaDoc.daDocAt,
    })
        .from(thongBao)
        .leftJoin(thongBaoDaDoc, and(eq(thongBaoDaDoc.thongBaoId, thongBao.id), eq(thongBaoDaDoc.nguoiDungId, userId)))
        .where(eq(thongBao.donViId, donViId))
        .orderBy(desc(thongBao.createdAt));
}
/** Dùng cho đơn vị hệ thống — xem gộp toàn bộ đơn vị đang hoạt động, kèm đơn vị sở hữu. */
export async function listThongBaoAllDonVi(userId) {
    const db = getDb();
    return db
        .select({
        thongBao,
        donVi: {
            id: donVi.id,
            maDonVi: donVi.maDonVi,
            tenDonVi: donVi.tenDonVi,
        },
        daDocAt: thongBaoDaDoc.daDocAt,
    })
        .from(thongBao)
        .leftJoin(thongBaoDaDoc, and(eq(thongBaoDaDoc.thongBaoId, thongBao.id), eq(thongBaoDaDoc.nguoiDungId, userId)))
        .innerJoin(donVi, eq(thongBao.donViId, donVi.id))
        .where(eq(donVi.trangThai, "hoat_dong"))
        .orderBy(donVi.tenDonVi, desc(thongBao.createdAt));
}
/**
 * Dùng cho phụ huynh có con học ở nhiều đơn vị — xem gộp đúng các đơn vị con
 * đang theo học, khác với `listThongBaoAllDonVi` (gộp TOÀN BỘ đơn vị, chỉ hợp
 * lý cho quản trị hệ thống).
 */
export async function listThongBaoByDonViIds(donViIds, userId, options) {
    const db = getDb();
    if (donViIds.length === 0) {
        return [];
    }
    const scopeConditions = [eq(thongBao.phamVi, "toan_truong")];
    if (options?.guardianClassIds?.length) {
        scopeConditions.push(and(eq(thongBao.phamVi, "theo_lop"), inArray(thongBao.lopHocId, options.guardianClassIds)));
    }
    if (options?.guardianStudentIds?.length) {
        scopeConditions.push(and(eq(thongBao.phamVi, "ca_nhan"), inArray(thongBao.hocSinhId, options.guardianStudentIds)));
    }
    return db
        .select({
        thongBao,
        donVi: {
            id: donVi.id,
            maDonVi: donVi.maDonVi,
            tenDonVi: donVi.tenDonVi,
        },
        daDocAt: thongBaoDaDoc.daDocAt,
    })
        .from(thongBao)
        .leftJoin(thongBaoDaDoc, and(eq(thongBaoDaDoc.thongBaoId, thongBao.id), eq(thongBaoDaDoc.nguoiDungId, userId)))
        .innerJoin(donVi, eq(thongBao.donViId, donVi.id))
        .where(and(inArray(thongBao.donViId, donViIds), or(...scopeConditions)))
        .orderBy(donVi.tenDonVi, desc(thongBao.createdAt));
}
/**
 * Dùng cho phụ huynh xem gộp nhiều đơn vị — đơn vị "đang chọn" của phụ huynh
 * (thường là một đơn vị neo chung) không nhất thiết trùng đơn vị sở hữu thông
 * báo. Việc kiểm tra thông báo có thuộc đúng đơn vị được phép xem hay không
 * do tầng service đảm nhiệm (so với danh sách đơn vị con đang học).
 */
export async function findThongBaoByIdAny(id) {
    const db = getDb();
    const rows = await db.select().from(thongBao).where(eq(thongBao.id, id)).limit(1);
    return rows[0] ?? null;
}
export async function findThongBaoById(donViId, id) {
    const db = getDb();
    const rows = await db
        .select()
        .from(thongBao)
        .where(and(eq(thongBao.id, id), eq(thongBao.donViId, donViId)))
        .limit(1);
    return rows[0] ?? null;
}
export async function findThongBaoDaDoc(thongBaoId, nguoiDungId) {
    const db = getDb();
    const rows = await db
        .select()
        .from(thongBaoDaDoc)
        .where(and(eq(thongBaoDaDoc.thongBaoId, thongBaoId), eq(thongBaoDaDoc.nguoiDungId, nguoiDungId)))
        .limit(1);
    return rows[0] ?? null;
}
export async function createThongBaoDaDoc(input) {
    const db = getDb();
    await db.insert(thongBaoDaDoc).values({
        thongBaoId: input.thongBaoId,
        nguoiDungId: input.nguoiDungId,
        daDocAt: input.daDocAt,
        createdAt: input.daDocAt,
    });
    return findThongBaoDaDoc(input.thongBaoId, input.nguoiDungId);
}
export async function countThongBaoTheoMaPrefix(donViId, prefix) {
    const db = getDb();
    const rows = await db
        .select({ total: count() })
        .from(thongBao)
        .where(and(eq(thongBao.donViId, donViId), like(thongBao.maThongBao, `${prefix}%`)));
    return rows[0]?.total ?? 0;
}
export async function createThongBao(input) {
    const db = getDb();
    await db.insert(thongBao).values({
        donViId: input.donViId,
        maThongBao: input.maThongBao,
        tieuDe: input.tieuDe,
        noiDung: input.noiDung,
        tepDinhKemTen: input.tepDinhKemTen,
        tepDinhKemUrl: input.tepDinhKemUrl,
        phamVi: input.phamVi,
        lopHocId: input.lopHocId,
        hocSinhId: input.hocSinhId,
        doiTuong: input.doiTuong,
        nguoiTaoId: input.nguoiTaoId,
        createdAt: now(),
        updatedAt: now(),
    });
    const rows = await db
        .select()
        .from(thongBao)
        .where(and(eq(thongBao.donViId, input.donViId), eq(thongBao.maThongBao, input.maThongBao)))
        .limit(1);
    return rows[0] ?? null;
}

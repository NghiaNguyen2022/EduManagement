import { and, eq, inArray, isNull } from "drizzle-orm";
import { nguoiDung, nguoiDungVaiTroDonVi, phienDangNhap, quyen, vaiTro, vaiTroQuyen, } from "../../drizzle/schema.js";
import { getDb } from "./connection.js";
const now = () => new Date().toISOString().slice(0, 19).replace("T", " ");
export async function listUsersByOrganization(organizationId) {
    const db = getDb();
    return db
        .select({
        id: nguoiDung.id,
        tenDangNhap: nguoiDung.tenDangNhap,
        hoTen: nguoiDung.hoTen,
        email: nguoiDung.email,
        soDienThoai: nguoiDung.soDienThoai,
        trangThai: nguoiDung.trangThai,
        batBuocDoiMatKhau: nguoiDung.batBuocDoiMatKhau,
        roleId: vaiTro.id,
        maVaiTro: vaiTro.maVaiTro,
        tenVaiTro: vaiTro.tenVaiTro,
        assignmentActive: nguoiDungVaiTroDonVi.dangHoatDong,
    })
        .from(nguoiDungVaiTroDonVi)
        .innerJoin(nguoiDung, eq(nguoiDungVaiTroDonVi.nguoiDungId, nguoiDung.id))
        .innerJoin(vaiTro, eq(nguoiDungVaiTroDonVi.vaiTroId, vaiTro.id))
        .where(eq(nguoiDungVaiTroDonVi.donViId, organizationId));
}
/**
 * Nhân viên trong 1 đơn vị đang giữ 1 quyền cụ thể — dùng để suy ra người
 * nhận thông báo sự kiện (VD: "ai có `tai_chinh.duyet` ở đơn vị này"), đúng
 * theo mô hình phân quyền `requirePermission` đang dùng, không hard-code
 * mã vai trò. Xem docs/analysis/THONG_BAO_SU_KIEN.md.
 */
export async function listNguoiDungTheoQuyen(donViId, maQuyen) {
    const db = getDb();
    const rows = await db
        .selectDistinct({
        id: nguoiDung.id,
        hoTen: nguoiDung.hoTen,
    })
        .from(nguoiDungVaiTroDonVi)
        .innerJoin(nguoiDung, eq(nguoiDungVaiTroDonVi.nguoiDungId, nguoiDung.id))
        .innerJoin(vaiTro, eq(nguoiDungVaiTroDonVi.vaiTroId, vaiTro.id))
        .innerJoin(vaiTroQuyen, eq(vaiTroQuyen.vaiTroId, vaiTro.id))
        .innerJoin(quyen, eq(vaiTroQuyen.quyenId, quyen.id))
        .where(and(eq(nguoiDungVaiTroDonVi.donViId, donViId), eq(nguoiDungVaiTroDonVi.dangHoatDong, true), eq(nguoiDung.trangThai, "hoat_dong"), eq(quyen.maQuyen, maQuyen)));
    return rows;
}
export async function listAssignableRoles() {
    const db = getDb();
    return db
        .select({
        id: vaiTro.id,
        maVaiTro: vaiTro.maVaiTro,
        tenVaiTro: vaiTro.tenVaiTro,
        phamVi: vaiTro.phamVi,
    })
        .from(vaiTro)
        .where(and(eq(vaiTro.dangHoatDong, true), inArray(vaiTro.phamVi, ["don_vi", "cong_thong_tin"])));
}
export async function findAssignableRoleById(roleId) {
    const db = getDb();
    const rows = await db
        .select()
        .from(vaiTro)
        .where(and(eq(vaiTro.id, roleId), eq(vaiTro.dangHoatDong, true), inArray(vaiTro.phamVi, ["don_vi", "cong_thong_tin"])))
        .limit(1);
    return rows[0] ?? null;
}
export async function findUserByUsername(username) {
    const db = getDb();
    const rows = await db.select().from(nguoiDung)
        .where(eq(nguoiDung.tenDangNhap, username)).limit(1);
    return rows[0] ?? null;
}
export async function findUserById(userId) {
    const db = getDb();
    const rows = await db.select().from(nguoiDung)
        .where(eq(nguoiDung.id, userId)).limit(1);
    return rows[0] ?? null;
}
export async function createUserWithRole(input) {
    const db = getDb();
    return db.transaction(async (tx) => {
        await tx.insert(nguoiDung).values({
            tenDangNhap: input.username,
            matKhauHash: input.passwordHash,
            hoTen: input.fullName,
            email: input.email ?? null,
            soDienThoai: input.phone ?? null,
            trangThai: "hoat_dong",
            batBuocDoiMatKhau: true,
            createdAt: now(),
            updatedAt: now(),
        });
        const rows = await tx.select().from(nguoiDung)
            .where(eq(nguoiDung.tenDangNhap, input.username)).limit(1);
        const created = rows[0];
        if (!created)
            throw new Error("Không thể tải tài khoản vừa tạo.");
        await tx.insert(nguoiDungVaiTroDonVi).values({
            nguoiDungId: created.id,
            vaiTroId: input.roleId,
            donViId: input.organizationId,
            dangHoatDong: true,
            createdAt: now(),
            updatedAt: now(),
        });
        return created;
    });
}
export async function updateUserStatus(input) {
    const db = getDb();
    await db.update(nguoiDung).set({
        trangThai: input.status,
        updatedAt: now(),
    }).where(eq(nguoiDung.id, input.userId));
}
export async function revokeAllUserSessions(userId) {
    const db = getDb();
    await db.update(phienDangNhap).set({
        huyLuc: now(),
        updatedAt: now(),
    }).where(and(eq(phienDangNhap.nguoiDungId, userId), isNull(phienDangNhap.huyLuc)));
}
export async function resetUserPassword(input) {
    const db = getDb();
    await db.update(nguoiDung).set({
        matKhauHash: input.passwordHash,
        batBuocDoiMatKhau: true,
        updatedAt: now(),
    }).where(eq(nguoiDung.id, input.userId));
}

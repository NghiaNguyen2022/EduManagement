export function hasAnyPermission(input) {
    return (input.grantedPermissions.includes("he_thong.quan_tri") ||
        input.requiredPermissions.some((code) => input.grantedPermissions.includes(code)));
}
export function hasAnyPermissionOrRole(input) {
    return (hasAnyPermission({
        grantedPermissions: input.grantedPermissions,
        requiredPermissions: input.requiredPermissions,
    }) ||
        input.requiredRoles.some((code) => input.grantedRoles.includes(code)));
}

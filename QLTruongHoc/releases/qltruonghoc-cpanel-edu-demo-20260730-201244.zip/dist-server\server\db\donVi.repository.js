import { and, count, eq, ne } from "drizzle-orm";
import { donVi, nguoiDungVaiTroDonVi, } from "../../drizzle/schema.js";
import { getDb } from "./connection.js";
const now = () => new Date().toISOString().slice(0, 19).replace("T", " ");
export async function listAllDonVi() {
    const db = getDb();
    return db
        .select()
        .from(donVi)
        .orderBy(donVi.donViChaId, donVi.tenDonVi);
}
export async function findDonViById(id) {
    const db = getDb();
    const rows = await db
        .select()
        .from(donVi)
        .where(eq(donVi.id, id))
        .limit(1);
    return rows[0] ?? null;
}
export async function findDonViByCode(maDonVi) {
    const db = getDb();
    const rows = await db
        .select()
        .from(donVi)
        .where(eq(donVi.maDonVi, maDonVi))
        .limit(1);
    return rows[0] ?? null;
}
export async function findHeThongDonVi() {
    const db = getDb();
    const rows = await db
        .select()
        .from(donVi)
        .where(eq(donVi.loaiDonVi, "he_thong"))
        .limit(1);
    return rows[0] ?? null;
}
export async function countActiveChildren(parentId) {
    const db = getDb();
    const rows = await db
        .select({ total: count() })
        .from(donVi)
        .where(and(eq(donVi.donViChaId, parentId), ne(donVi.trangThai, "ngung_hoat_dong")));
    return rows[0]?.total ?? 0;
}
export async function countActiveAssignments(donViId) {
    const db = getDb();
    const rows = await db
        .select({ total: count() })
        .from(nguoiDungVaiTroDonVi)
        .where(and(eq(nguoiDungVaiTroDonVi.donViId, donViId), eq(nguoiDungVaiTroDonVi.dangHoatDong, true)));
    return rows[0]?.total ?? 0;
}
export async function createDonVi(input) {
    const db = getDb();
    await db.insert(donVi).values({
        donViChaId: input.donViChaId,
        maDonVi: input.maDonVi,
        tenDonVi: input.tenDonVi,
        loaiDonVi: input.loaiDonVi,
        loaiHinhDaoTao: input.loaiHinhDaoTao,
        diaChi: input.diaChi,
        soDienThoai: input.soDienThoai,
        email: input.email,
        hinhAnhUrl: input.hinhAnhUrl,
        nguoiDaiDien: input.nguoiDaiDien,
        maSoThue: input.maSoThue,
        maGiayPhep: input.maGiayPhep,
        giayPhepUrl: input.giayPhepUrl,
        trangThai: "hoat_dong",
        createdAt: now(),
        updatedAt: now(),
    });
    return findDonViByCode(input.maDonVi);
}
export async function updateDonVi(input) {
    const db = getDb();
    await db
        .update(donVi)
        .set({
        tenDonVi: input.tenDonVi,
        loaiDonVi: input.loaiDonVi,
        loaiHinhDaoTao: input.loaiHinhDaoTao,
        diaChi: input.diaChi,
        soDienThoai: input.soDienThoai,
        email: input.email,
        hinhAnhUrl: input.hinhAnhUrl,
        nguoiDaiDien: input.nguoiDaiDien,
        maSoThue: input.maSoThue,
        maGiayPhep: input.maGiayPhep,
        giayPhepUrl: input.giayPhepUrl,
        updatedAt: now(),
    })
        .where(eq(donVi.id, input.id));
    return findDonViById(input.id);
}
export async function updateDonViStatus(input) {
    const db = getDb();
    await db
        .update(donVi)
        .set({
        trangThai: input.trangThai,
        updatedAt: now(),
    })
        .where(eq(donVi.id, input.id));
    return findDonViById(input.id);
}

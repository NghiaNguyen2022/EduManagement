import { hasAnyPermission, hasAnyPermissionOrRole, } from "../domain/access-control.js";
export function requireCurrentOrganization(req, res, next) {
    if (!req.auth?.currentOrganization) {
        res.status(409).json({
            ok: false,
            error: "Vui lòng chọn đơn vị làm việc.",
        });
        return;
    }
    next();
}
export function requirePermission(permissionCode) {
    return (req, res, next) => {
        const organization = req.auth?.currentOrganization;
        if (!organization) {
            res.status(409).json({
                ok: false,
                error: "Vui lòng chọn đơn vị làm việc.",
            });
            return;
        }
        if (!hasAnyPermission({
            grantedPermissions: organization.quyen,
            requiredPermissions: [permissionCode],
        })) {
            res.status(403).json({
                ok: false,
                error: "Bạn không có quyền thực hiện thao tác này.",
            });
            return;
        }
        next();
    };
}
/**
 * Cho phép thao tác nếu người dùng có ÍT NHẤT MỘT trong các mã quyền được liệt kê.
 * Dùng cho hành động hợp lý với từ hai vai trò trở lên, tránh phải cấp chéo quyền
 * cho từng vai trò riêng lẻ.
 */
export function requireAnyPermission(permissionCodes) {
    return (req, res, next) => {
        const organization = req.auth?.currentOrganization;
        if (!organization) {
            res.status(409).json({
                ok: false,
                error: "Vui lòng chọn đơn vị làm việc.",
            });
            return;
        }
        if (!hasAnyPermission({
            grantedPermissions: organization.quyen,
            requiredPermissions: permissionCodes,
        })) {
            res.status(403).json({
                ok: false,
                error: "Bạn không có quyền thực hiện thao tác này.",
            });
            return;
        }
        next();
    };
}
/**
 * Cho phép thao tác nếu có ít nhất một mã quyền được liệt kê, HOẶC vai trò tại
 * đơn vị hiện tại nằm trong danh sách vai trò được liệt kê. Dùng cho các thao
 * tác "chỉ xem" mà một vai trò không có hệ thống mã quyền riêng (ví dụ
 * `phu_huynh`) vẫn cần truy cập được — theo đúng cách `portal.router.ts` đã
 * kiểm tra `vaiTro` trực tiếp, không cấp thêm mã quyền quản lý cho vai trò đó.
 */
export function requireAnyPermissionOrRole(permissionCodes, roleCodes) {
    return (req, res, next) => {
        const organization = req.auth?.currentOrganization;
        if (!organization) {
            res.status(409).json({
                ok: false,
                error: "Vui lòng chọn đơn vị làm việc.",
            });
            return;
        }
        if (!hasAnyPermissionOrRole({
            grantedPermissions: organization.quyen,
            grantedRoles: organization.vaiTro,
            requiredPermissions: permissionCodes,
            requiredRoles: roleCodes,
        })) {
            res.status(403).json({
                ok: false,
                error: "Bạn không có quyền thực hiện thao tác này.",
            });
            return;
        }
        next();
    };
}

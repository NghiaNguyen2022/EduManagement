import { createHash, randomBytes } from "node:crypto";
export function createSessionToken() {
    return randomBytes(48).toString("base64url");
}
export function hashSessionToken(token) {
    return createHash("sha256").update(token).digest("hex");
}

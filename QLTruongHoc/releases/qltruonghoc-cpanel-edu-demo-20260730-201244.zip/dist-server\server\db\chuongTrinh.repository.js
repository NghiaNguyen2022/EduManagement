import { and, count, eq, like } from "drizzle-orm";
import { chuongTrinhDaoTao, donVi } from "../../drizzle/schema.js";
import { getDb } from "./connection.js";
const now = () => new Date().toISOString().slice(0, 19).replace("T", " ");
export async function listChuongTrinhByDonVi(donViId) {
    const db = getDb();
    return db
        .select()
        .from(chuongTrinhDaoTao)
        .where(eq(chuongTrinhDaoTao.donViId, donViId))
        .orderBy(chuongTrinhDaoTao.tenChuongTrinh);
}
/** Dùng cho đơn vị hệ thống — xem gộp toàn bộ đơn vị đang hoạt động, kèm đơn vị sở hữu. */
export async function listChuongTrinhAllDonVi() {
    const db = getDb();
    return db
        .select({
        chuongTrinh: chuongTrinhDaoTao,
        donVi: {
            id: donVi.id,
            maDonVi: donVi.maDonVi,
            tenDonVi: donVi.tenDonVi,
        },
    })
        .from(chuongTrinhDaoTao)
        .innerJoin(donVi, eq(chuongTrinhDaoTao.donViId, donVi.id))
        .where(eq(donVi.trangThai, "hoat_dong"))
        .orderBy(donVi.tenDonVi, chuongTrinhDaoTao.tenChuongTrinh);
}
export async function findChuongTrinhById(donViId, id) {
    const db = getDb();
    const rows = await db
        .select()
        .from(chuongTrinhDaoTao)
        .where(and(eq(chuongTrinhDaoTao.id, id), eq(chuongTrinhDaoTao.donViId, donViId)))
        .limit(1);
    return rows[0] ?? null;
}
export async function findChuongTrinhByMa(donViId, maChuongTrinh) {
    const db = getDb();
    const rows = await db
        .select()
        .from(chuongTrinhDaoTao)
        .where(and(eq(chuongTrinhDaoTao.donViId, donViId), eq(chuongTrinhDaoTao.maChuongTrinh, maChuongTrinh)))
        .limit(1);
    return rows[0] ?? null;
}
export async function countChuongTrinhTheoMaPrefix(donViId, prefix) {
    const db = getDb();
    const rows = await db
        .select({ total: count() })
        .from(chuongTrinhDaoTao)
        .where(and(eq(chuongTrinhDaoTao.donViId, donViId), like(chuongTrinhDaoTao.maChuongTrinh, `${prefix}%`)));
    return rows[0]?.total ?? 0;
}
export async function createChuongTrinh(input) {
    const db = getDb();
    await db.insert(chuongTrinhDaoTao).values({
        donViId: input.donViId,
        maChuongTrinh: input.maChuongTrinh,
        tenChuongTrinh: input.tenChuongTrinh,
        capDo: input.capDo,
        tongSoBuoi: input.tongSoBuoi,
        tongSoGio: input.tongSoGio,
        moTa: input.moTa,
        coTestDauVao: input.coTestDauVao,
        trangThai: "hoat_dong",
        createdAt: now(),
        updatedAt: now(),
    });
    return findChuongTrinhByMa(input.donViId, input.maChuongTrinh);
}
export async function updateChuongTrinh(input) {
    const db = getDb();
    await db
        .update(chuongTrinhDaoTao)
        .set({
        tenChuongTrinh: input.tenChuongTrinh,
        capDo: input.capDo,
        tongSoBuoi: input.tongSoBuoi,
        tongSoGio: input.tongSoGio,
        moTa: input.moTa,
        coTestDauVao: input.coTestDauVao,
        updatedAt: now(),
    })
        .where(eq(chuongTrinhDaoTao.id, input.id));
    const rows = await db
        .select()
        .from(chuongTrinhDaoTao)
        .where(eq(chuongTrinhDaoTao.id, input.id))
        .limit(1);
    return rows[0] ?? null;
}
export async function setChuongTrinhTrangThai(input) {
    const db = getDb();
    await db
        .update(chuongTrinhDaoTao)
        .set({
        trangThai: input.trangThai,
        updatedAt: now(),
    })
        .where(eq(chuongTrinhDaoTao.id, input.id));
    const rows = await db
        .select()
        .from(chuongTrinhDaoTao)
        .where(eq(chuongTrinhDaoTao.id, input.id))
        .limit(1);
    return rows[0] ?? null;
}

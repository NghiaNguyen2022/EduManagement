import { and, count, eq, inArray, like } from "drizzle-orm";
import { hocSinh, hocSinhLopHoc, hocSinhPhuHuynh, phuHuynh, } from "../../drizzle/schema.js";
import { getDb } from "./connection.js";
const now = () => new Date().toISOString().slice(0, 19).replace("T", " ");
export async function findPhuHuynhByPhone(donViId, dienThoai) {
    const db = getDb();
    const rows = await db
        .select()
        .from(phuHuynh)
        .where(and(eq(phuHuynh.donViId, donViId), eq(phuHuynh.dienThoai, dienThoai)))
        .limit(1);
    return rows[0] ?? null;
}
export async function findPhuHuynhByPhoneGlobal(dienThoai) {
    const db = getDb();
    const rows = await db.select().from(phuHuynh).where(eq(phuHuynh.dienThoai, dienThoai)).limit(1);
    return rows[0] ?? null;
}
export async function findPhuHuynhByNguoiDungId(donViId, nguoiDungId) {
    const db = getDb();
    const rows = await db
        .select()
        .from(phuHuynh)
        .where(and(eq(phuHuynh.donViId, donViId), eq(phuHuynh.nguoiDungId, nguoiDungId)))
        .limit(1);
    return rows[0] ?? null;
}
export async function listPhuHuynhByNguoiDungId(nguoiDungId) {
    const db = getDb();
    return db.select().from(phuHuynh).where(eq(phuHuynh.nguoiDungId, nguoiDungId));
}
export async function listGuardianNotificationScopeRows(nguoiDungId) {
    const db = getDb();
    return db
        .select({
        hocSinhId: hocSinh.id,
        donViId: hocSinh.donViId,
        lopHocId: hocSinhLopHoc.lopHocId,
    })
        .from(phuHuynh)
        .innerJoin(hocSinhPhuHuynh, eq(hocSinhPhuHuynh.phuHuynhId, phuHuynh.id))
        .innerJoin(hocSinh, eq(hocSinh.id, hocSinhPhuHuynh.hocSinhId))
        .leftJoin(hocSinhLopHoc, and(eq(hocSinhLopHoc.hocSinhId, hocSinh.id), inArray(hocSinhLopHoc.trangThai, ["dang_hoc", "bao_luu"])))
        .where(and(eq(phuHuynh.nguoiDungId, nguoiDungId), eq(hocSinhPhuHuynh.nhanThongBao, true), eq(phuHuynh.trangThai, "hoat_dong")));
}
export async function updatePhuHuynhNguoiDungId(input) {
    const db = getDb();
    await db
        .update(phuHuynh)
        .set({
        nguoiDungId: input.nguoiDungId,
        updatedAt: now(),
    })
        .where(eq(phuHuynh.id, input.id));
}
export async function findPhuHuynhById(id) {
    const db = getDb();
    const rows = await db.select().from(phuHuynh).where(eq(phuHuynh.id, id)).limit(1);
    return rows[0] ?? null;
}
export async function countPhuHuynhTheoMaPrefix(donViId, prefix) {
    const db = getDb();
    const rows = await db
        .select({ total: count() })
        .from(phuHuynh)
        .where(and(eq(phuHuynh.donViId, donViId), like(phuHuynh.maPhuHuynh, `${prefix}%`)));
    return rows[0]?.total ?? 0;
}
export async function createPhuHuynh(input) {
    const db = getDb();
    await db.insert(phuHuynh).values({
        donViId: input.donViId,
        maPhuHuynh: input.maPhuHuynh,
        hoTen: input.hoTen,
        ngaySinh: input.ngaySinh,
        gioiTinh: input.gioiTinh,
        dienThoai: input.dienThoai,
        email: input.email,
        ngheNghiep: input.ngheNghiep,
        diaChi: input.diaChi,
        trangThai: "hoat_dong",
        createdAt: now(),
        updatedAt: now(),
    });
    return findPhuHuynhByPhone(input.donViId, input.dienThoai);
}
export async function listGuardianLinksByHocSinh(hocSinhId) {
    const db = getDb();
    return db
        .select({
        lienKet: hocSinhPhuHuynh,
        phuHuynh,
    })
        .from(hocSinhPhuHuynh)
        .innerJoin(phuHuynh, eq(hocSinhPhuHuynh.phuHuynhId, phuHuynh.id))
        .where(eq(hocSinhPhuHuynh.hocSinhId, hocSinhId));
}
export async function listHocSinhByPhuHuynhId(phuHuynhId) {
    const db = getDb();
    return db
        .select({
        lienKet: hocSinhPhuHuynh,
        hocSinh,
    })
        .from(hocSinhPhuHuynh)
        .innerJoin(hocSinh, eq(hocSinhPhuHuynh.hocSinhId, hocSinh.id))
        .where(eq(hocSinhPhuHuynh.phuHuynhId, phuHuynhId))
        .orderBy(hocSinh.hoTen);
}
export async function findGuardianLink(hocSinhId, phuHuynhId) {
    const db = getDb();
    const rows = await db
        .select()
        .from(hocSinhPhuHuynh)
        .where(and(eq(hocSinhPhuHuynh.hocSinhId, hocSinhId), eq(hocSinhPhuHuynh.phuHuynhId, phuHuynhId)))
        .limit(1);
    return rows[0] ?? null;
}
export async function findGuardianLinkById(linkId) {
    const db = getDb();
    const rows = await db
        .select({
        lienKet: hocSinhPhuHuynh,
        donViId: hocSinh.donViId,
    })
        .from(hocSinhPhuHuynh)
        .innerJoin(hocSinh, eq(hocSinhPhuHuynh.hocSinhId, hocSinh.id))
        .where(eq(hocSinhPhuHuynh.id, linkId))
        .limit(1);
    return rows[0] ?? null;
}
export async function countGuardianLinksForHocSinh(hocSinhId) {
    const db = getDb();
    const rows = await db
        .select({ total: count() })
        .from(hocSinhPhuHuynh)
        .where(eq(hocSinhPhuHuynh.hocSinhId, hocSinhId));
    return rows[0]?.total ?? 0;
}
export async function clearPrimaryContact(hocSinhId) {
    const db = getDb();
    await db
        .update(hocSinhPhuHuynh)
        .set({
        laLienHeChinh: false,
        updatedAt: now(),
    })
        .where(eq(hocSinhPhuHuynh.hocSinhId, hocSinhId));
}
export async function createGuardianLink(input) {
    const db = getDb();
    await db.insert(hocSinhPhuHuynh).values({
        hocSinhId: input.hocSinhId,
        phuHuynhId: input.phuHuynhId,
        moiQuanHe: input.moiQuanHe,
        laLienHeChinh: input.laLienHeChinh,
        duocDonTre: input.duocDonTre,
        nhanThongBao: input.nhanThongBao,
        nhanThongTinHocPhi: input.nhanThongTinHocPhi,
        createdAt: now(),
        updatedAt: now(),
    });
    return findGuardianLink(input.hocSinhId, input.phuHuynhId);
}
export async function updateGuardianLink(input) {
    const db = getDb();
    await db
        .update(hocSinhPhuHuynh)
        .set({
        moiQuanHe: input.moiQuanHe,
        laLienHeChinh: input.laLienHeChinh,
        duocDonTre: input.duocDonTre,
        nhanThongBao: input.nhanThongBao,
        nhanThongTinHocPhi: input.nhanThongTinHocPhi,
        updatedAt: now(),
    })
        .where(eq(hocSinhPhuHuynh.id, input.id));
    const rows = await db
        .select()
        .from(hocSinhPhuHuynh)
        .where(eq(hocSinhPhuHuynh.id, input.id))
        .limit(1);
    return rows[0] ?? null;
}
export async function deleteGuardianLink(id) {
    const db = getDb();
    await db.delete(hocSinhPhuHuynh).where(eq(hocSinhPhuHuynh.id, id));
}

﻿Thư mục chứa file người dùng tải lên. Giữ nguyên thư mục này khi cập nhật.

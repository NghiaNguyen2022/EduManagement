import { createAuditLog } from "../db/audit.repository.js";
import { createTraoDoi, listTraoDoiAllDonVi, listTraoDoiByDonVi, } from "../db/traoDoi.repository.js";
import { findHocSinhById } from "../db/hocSinh.repository.js";
import { findLopHocById, listActiveEnrollmentsByHocSinh } from "../db/lopHoc.repository.js";
import { assertDonViChoPhepNghiepVu } from "./donVi.service.js";
const NGUOI_GUI_HOP_LE = ["giao_vien", "phu_huynh", "hoc_vu", "khac"];
const KENH_HOP_LE = ["truc_tiep", "dien_thoai", "nhan_tin", "email", "khac"];
function normalizeText(value) {
    return value.trim();
}
export async function listTraoDoi(donViId, loaiDonVi, filters = {}) {
    if (loaiDonVi === "he_thong") {
        return listTraoDoiAllDonVi(filters);
    }
    return listTraoDoiByDonVi(donViId, filters);
}
export async function createTraoDoiMoi(input) {
    await assertDonViChoPhepNghiepVu(input.donViId);
    const hocSinh = await findHocSinhById(input.donViId, input.hocSinhId);
    if (!hocSinh) {
        throw new Error("Không tìm thấy học sinh trong đơn vị hiện tại.");
    }
    const noiDung = normalizeText(input.noiDung);
    if (!noiDung) {
        throw new Error("Vui lòng nhập nội dung trao đổi.");
    }
    if (!NGUOI_GUI_HOP_LE.includes(input.nguoiGuiVaiTro)) {
        throw new Error("Vai trò người ghi trao đổi không hợp lệ.");
    }
    if (!KENH_HOP_LE.includes(input.kenhLienLac)) {
        throw new Error("Kênh liên lạc không hợp lệ.");
    }
    if (input.lopHocId) {
        const lopHoc = await findLopHocById(input.donViId, input.lopHocId);
        if (!lopHoc) {
            throw new Error("Không tìm thấy lớp học trong đơn vị hiện tại.");
        }
        const activeEnrollments = await listActiveEnrollmentsByHocSinh(input.hocSinhId);
        if (!activeEnrollments.some((enrollment) => enrollment.lopHocId === input.lopHocId)) {
            throw new Error("Học sinh chưa đang theo học lớp đã chọn.");
        }
    }
    const created = await createTraoDoi({
        donViId: input.donViId,
        hocSinhId: input.hocSinhId,
        lopHocId: input.lopHocId ?? null,
        nguoiGuiVaiTro: input.nguoiGuiVaiTro,
        kenhLienLac: input.kenhLienLac,
        noiDung,
        ketQua: normalizeText(input.ketQua ?? "") || null,
        nguoiTaoId: input.actorUserId,
    });
    if (!created) {
        throw new Error("Không thể tạo trao đổi.");
    }
    await createAuditLog({
        userId: input.actorUserId,
        organizationId: input.donViId,
        action: "trao_doi.create",
        objectType: "TraoDoiHocSinh",
        objectId: String(created.traoDoi.id),
        content: `Tạo trao đổi cho học sinh ${created.hocSinh.hoTen} (${created.hocSinh.maHocSinh}).`,
        ipAddress: input.ipAddress,
    });
    return created;
}

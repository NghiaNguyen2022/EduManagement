import { nhatKyHeThong } from "../../drizzle/schema.js";
import { getDb } from "./connection.js";
import { toDatabaseDateTime } from "../utils/dateTime.js";
const now = toDatabaseDateTime;
export async function createAuditLog(input) {
    const db = getDb();
    await db.insert(nhatKyHeThong).values({
        nguoiDungId: input.userId ?? null,
        donViId: input.organizationId ?? null,
        hanhDong: input.action,
        doiTuong: input.objectType ?? null,
        doiTuongId: input.objectId ?? null,
        noiDung: input.content ?? null,
        duLieu: input.data === undefined
            ? null
            : JSON.stringify(input.data),
        mucDo: input.level ?? "thong_tin",
        diaChiIp: input.ipAddress ?? null,
        createdAt: now(),
    });
}

import { createAuditLog, } from "../db/audit.repository.js";
import { assignTuVanVien, convertLeadToHocSinh, countLeadTheoMaPrefix, createLead, createLeadHoatDong, findLeadById, findLeadHoatDongById, listLeadAllDonVi, listLeadByDonVi, listLeadHoatDong, listLichHenSapToi, updateLeadHoatDongTrangThai, updateLeadInfo, updateLeadTrangThai, } from "../db/lead.repository.js";
import { assertDonViChoPhepNghiepVu } from "./donVi.service.js";
import { createHocSinhMoi } from "./hocSinh.service.js";
import { addGuardianToStudent } from "./phuHuynh.service.js";
const NGUON_HOP_LE = [
    "gioi_thieu",
    "facebook",
    "website",
    "walk_in",
    "khac",
];
const TRANG_THAI_QUA_HOAT_DONG = [
    "moi",
    "dang_cham_soc",
    "da_hen_lich",
    "da_hoc_thu",
    "khong_tiep_tuc",
];
const LOAI_HOAT_DONG_HOP_LE = [
    "goi_dien",
    "gap_truc_tiep",
    "nhan_tin",
    "hen_lich",
    "hoc_thu",
    "khac",
];
const MOI_QUAN_HE_HOP_LE = [
    "cha",
    "me",
    "ong",
    "ba",
    "nguoi_giam_ho",
    "khac",
];
function nowDateTime() {
    return new Date().toISOString().slice(0, 19).replace("T", " ");
}
async function sinhMaLead(donViId) {
    const nam = new Date().getFullYear();
    const prefix = `LD${nam}`;
    const total = await countLeadTheoMaPrefix(donViId, prefix);
    return `${prefix}${String(total + 1).padStart(4, "0")}`;
}
export async function listLead(donViId, loaiDonVi) {
    if (loaiDonVi === "he_thong") {
        return listLeadAllDonVi();
    }
    return listLeadByDonVi(donViId);
}
export async function getLeadDetail(donViId, leadId) {
    const found = await findLeadById(donViId, leadId);
    if (!found) {
        throw new Error("Không tìm thấy lead trong đơn vị hiện tại.");
    }
    const hoatDong = await listLeadHoatDong(leadId);
    return { lead: found, hoatDong };
}
export async function createLeadMoi(input) {
    await assertDonViChoPhepNghiepVu(input.donViId);
    const hoTen = input.hoTen.trim();
    const soDienThoai = input.soDienThoai.trim();
    if (!hoTen) {
        throw new Error("Vui lòng nhập họ tên người liên hệ.");
    }
    if (!soDienThoai) {
        throw new Error("Vui lòng nhập số điện thoại.");
    }
    const nguon = (input.nguon || "khac");
    if (!NGUON_HOP_LE.includes(nguon)) {
        throw new Error("Nguồn lead không hợp lệ.");
    }
    const maLead = await sinhMaLead(input.donViId);
    const created = await createLead({
        donViId: input.donViId,
        maLead,
        hoTen,
        soDienThoai,
        email: input.email?.trim() || null,
        nguon,
        doTuoiHoacTrinhDo: input.doTuoiHoacTrinhDo?.trim() || null,
        nhuCau: input.nhuCau?.trim() || null,
        tuVanVienId: input.tuVanVienId ?? null,
    });
    if (!created) {
        throw new Error("Không thể tạo lead.");
    }
    await createAuditLog({
        userId: input.actorUserId,
        organizationId: input.donViId,
        action: "lead.create",
        objectType: "Lead",
        objectId: String(created.id),
        content: `Tạo lead ${created.hoTen} (${created.maLead}).`,
        ipAddress: input.ipAddress,
    });
    return created;
}
export async function updateLeadThongTin(input) {
    const existing = await findLeadById(input.donViId, input.id);
    if (!existing) {
        throw new Error("Không tìm thấy lead trong đơn vị hiện tại.");
    }
    if (existing.trangThai === "da_dang_ky") {
        throw new Error("Lead đã xác nhận đăng ký, không thể sửa thông tin.");
    }
    const hoTen = input.hoTen.trim();
    const soDienThoai = input.soDienThoai.trim();
    if (!hoTen) {
        throw new Error("Vui lòng nhập họ tên người liên hệ.");
    }
    if (!soDienThoai) {
        throw new Error("Vui lòng nhập số điện thoại.");
    }
    const nguon = (input.nguon || "khac");
    if (!NGUON_HOP_LE.includes(nguon)) {
        throw new Error("Nguồn lead không hợp lệ.");
    }
    const updated = await updateLeadInfo({
        id: input.id,
        hoTen,
        soDienThoai,
        email: input.email?.trim() || null,
        nguon,
        doTuoiHoacTrinhDo: input.doTuoiHoacTrinhDo?.trim() || null,
        nhuCau: input.nhuCau?.trim() || null,
    });
    if (!updated) {
        throw new Error("Không thể cập nhật lead.");
    }
    await createAuditLog({
        userId: input.actorUserId,
        organizationId: input.donViId,
        action: "lead.update",
        objectType: "Lead",
        objectId: String(updated.id),
        content: `Cập nhật thông tin lead ${updated.hoTen} (${updated.maLead}).`,
        ipAddress: input.ipAddress,
    });
    return updated;
}
export async function assignLeadTuVanVien(input) {
    const existing = await findLeadById(input.donViId, input.id);
    if (!existing) {
        throw new Error("Không tìm thấy lead trong đơn vị hiện tại.");
    }
    const updated = await assignTuVanVien({
        id: input.id,
        tuVanVienId: input.tuVanVienId,
    });
    if (!updated) {
        throw new Error("Không thể phân công tư vấn viên.");
    }
    await createAuditLog({
        userId: input.actorUserId,
        organizationId: input.donViId,
        action: "lead.assign",
        objectType: "Lead",
        objectId: String(updated.id),
        content: `Phân công tư vấn viên cho lead ${updated.hoTen} (${updated.maLead}).`,
        ipAddress: input.ipAddress,
    });
    return updated;
}
export async function addLeadHoatDongMoi(input) {
    const existing = await findLeadById(input.donViId, input.leadId);
    if (!existing) {
        throw new Error("Không tìm thấy lead trong đơn vị hiện tại.");
    }
    if (existing.trangThai === "da_dang_ky" ||
        existing.trangThai === "khong_tiep_tuc") {
        throw new Error("Lead đã đóng (đã đăng ký hoặc không tiếp tục), không thể ghi thêm hoạt động. Hãy mở lại trạng thái trước.");
    }
    if (!LOAI_HOAT_DONG_HOP_LE.includes(input.loaiHoatDong)) {
        throw new Error("Loại hoạt động không hợp lệ.");
    }
    const noiDung = input.noiDung.trim();
    if (!noiDung) {
        throw new Error("Vui lòng nhập nội dung hoạt động.");
    }
    // "Hẹn lịch" là task thật — tạo ở chờ xử lý để hiện trong "Lịch hẹn sắp
    // tới" và cần tư vấn viên chủ động đánh dấu đã thực hiện/huỷ sau. Các loại
    // hoạt động khác là log việc đã xảy ra, không cần luồng task.
    const trangThai = input.loaiHoatDong === "hen_lich" ? "cho_xu_ly" : "da_xu_ly";
    const activity = await createLeadHoatDong({
        leadId: input.leadId,
        loaiHoatDong: input.loaiHoatDong,
        noiDung,
        ketQua: input.ketQua?.trim() || null,
        nguoiThucHienId: input.actorUserId,
        thoiGian: input.thoiGian || nowDateTime(),
        trangThai,
    });
    await createAuditLog({
        userId: input.actorUserId,
        organizationId: input.donViId,
        action: "lead.add_activity",
        objectType: "LeadHoatDong",
        objectId: activity ? String(activity.id) : null,
        content: `Ghi nhận hoạt động chăm sóc lead ${existing.hoTen} (${existing.maLead}).`,
        ipAddress: input.ipAddress,
    });
    if (input.trangThaiMoi &&
        input.trangThaiMoi !== existing.trangThai) {
        if (!TRANG_THAI_QUA_HOAT_DONG.includes(input.trangThaiMoi)) {
            throw new Error("Không thể chuyển sang trạng thái này qua ghi nhận hoạt động. Trạng thái đã đăng ký chỉ được đặt qua xác nhận đăng ký.");
        }
        if (input.trangThaiMoi === "khong_tiep_tuc") {
            throw new Error("Vui lòng dùng chức năng đánh dấu không tiếp tục để nhập lý do.");
        }
        const updated = await updateLeadTrangThai({
            id: input.leadId,
            trangThai: input.trangThaiMoi,
            lyDoKhongTiepTuc: null,
        });
        await createAuditLog({
            userId: input.actorUserId,
            organizationId: input.donViId,
            action: "lead.change_status",
            objectType: "Lead",
            objectId: String(input.leadId),
            content: `Đổi trạng thái lead sang ${input.trangThaiMoi}.`,
            ipAddress: input.ipAddress,
        });
        return { activity, lead: updated };
    }
    return { activity, lead: existing };
}
/** Lịch hẹn (hen_lich) còn chờ xử lý — dùng cho "Lịch hẹn sắp tới" ở LeadsPage. */
export async function getLichHenSapToi(donViId) {
    return listLichHenSapToi(donViId);
}
/** Đánh dấu một lịch hẹn đã thực hiện hoặc huỷ — chuyển task khỏi "sắp tới". */
export async function xuLyLichHen(input) {
    const found = await findLeadHoatDongById(input.hoatDongId);
    if (!found || found.donViId !== input.donViId) {
        throw new Error("Không tìm thấy hoạt động chăm sóc.");
    }
    if (found.hoatDong.loaiHoatDong !== "hen_lich") {
        throw new Error("Chỉ xử lý được với hoạt động loại hẹn lịch.");
    }
    if (found.hoatDong.trangThai !== "cho_xu_ly") {
        throw new Error("Lịch hẹn này đã được xử lý.");
    }
    const updated = await updateLeadHoatDongTrangThai({
        id: input.hoatDongId,
        trangThai: input.trangThai,
    });
    await createAuditLog({
        userId: input.actorUserId,
        organizationId: input.donViId,
        action: input.trangThai === "da_xu_ly" ? "lead.hen_lich.done" : "lead.hen_lich.huy",
        objectType: "LeadHoatDong",
        objectId: String(input.hoatDongId),
        content: `${input.trangThai === "da_xu_ly" ? "Đánh dấu đã thực hiện" : "Huỷ"} lịch hẹn #${input.hoatDongId}.`,
        ipAddress: input.ipAddress,
    });
    return updated;
}
export async function markLeadKhongTiepTuc(input) {
    const existing = await findLeadById(input.donViId, input.id);
    if (!existing) {
        throw new Error("Không tìm thấy lead trong đơn vị hiện tại.");
    }
    if (existing.trangThai === "da_dang_ky") {
        throw new Error("Lead đã đăng ký, không thể đánh dấu không tiếp tục.");
    }
    const lyDo = input.lyDo.trim();
    if (!lyDo) {
        throw new Error("Vui lòng nhập lý do không tiếp tục.");
    }
    const updated = await updateLeadTrangThai({
        id: input.id,
        trangThai: "khong_tiep_tuc",
        lyDoKhongTiepTuc: lyDo,
    });
    await createAuditLog({
        userId: input.actorUserId,
        organizationId: input.donViId,
        action: "lead.mark_not_continuing",
        objectType: "Lead",
        objectId: String(input.id),
        content: `Đánh dấu lead ${existing.hoTen} (${existing.maLead}) không tiếp tục: ${lyDo}`,
        ipAddress: input.ipAddress,
    });
    return updated;
}
export async function reopenLead(input) {
    const existing = await findLeadById(input.donViId, input.id);
    if (!existing) {
        throw new Error("Không tìm thấy lead trong đơn vị hiện tại.");
    }
    if (existing.trangThai !== "khong_tiep_tuc") {
        throw new Error("Chỉ mở lại được lead đang ở trạng thái không tiếp tục.");
    }
    const updated = await updateLeadTrangThai({
        id: input.id,
        trangThai: "dang_cham_soc",
        lyDoKhongTiepTuc: null,
    });
    await createAuditLog({
        userId: input.actorUserId,
        organizationId: input.donViId,
        action: "lead.reopen",
        objectType: "Lead",
        objectId: String(input.id),
        content: `Mở lại lead ${existing.hoTen} (${existing.maLead}).`,
        ipAddress: input.ipAddress,
    });
    return updated;
}
export async function confirmLeadRegistration(input) {
    const existing = await findLeadById(input.donViId, input.leadId);
    if (!existing) {
        throw new Error("Không tìm thấy lead trong đơn vị hiện tại.");
    }
    if (existing.trangThai === "da_dang_ky") {
        throw new Error("Lead này đã xác nhận đăng ký trước đó.");
    }
    if (existing.trangThai === "khong_tiep_tuc") {
        throw new Error("Lead đang ở trạng thái không tiếp tục. Vui lòng mở lại trước khi xác nhận đăng ký.");
    }
    if (!MOI_QUAN_HE_HOP_LE.includes(input.moiQuanHe)) {
        throw new Error("Mối quan hệ không hợp lệ.");
    }
    const hocSinhMoi = await createHocSinhMoi({
        donViId: input.donViId,
        hoTen: input.hoTenHocVien,
        ngaySinh: input.ngaySinh,
        gioiTinh: input.gioiTinh ?? null,
        diaChi: input.diaChiHocVien ?? null,
        ngayNhapHoc: input.ngayNhapHoc ?? null,
        // Carry nguyện vọng từ lead sang học sinh — học vụ dùng để xếp lớp sau
        // này (không xếp lớp ở bước này nữa, xem docs/analysis/TUYEN_SINH_THEO_LOAI_HINH.md).
        nguyenVongLop: existing.nhuCau,
        actorUserId: input.actorUserId,
        ipAddress: input.ipAddress,
    });
    await addGuardianToStudent({
        donViId: input.donViId,
        hocSinhId: hocSinhMoi.id,
        dienThoai: existing.soDienThoai,
        hoTen: existing.hoTen,
        email: existing.email,
        moiQuanHe: input.moiQuanHe,
        laLienHeChinh: true,
        duocDonTre: true,
        nhanThongBao: true,
        nhanThongTinHocPhi: true,
        actorUserId: input.actorUserId,
        ipAddress: input.ipAddress,
    });
    const updatedLead = await convertLeadToHocSinh({
        id: input.leadId,
        hocSinhId: hocSinhMoi.id,
    });
    await createAuditLog({
        userId: input.actorUserId,
        organizationId: input.donViId,
        action: "lead.confirm_registration",
        objectType: "Lead",
        objectId: String(input.leadId),
        content: `Xác nhận đăng ký lead ${existing.hoTen} (${existing.maLead}) thành học sinh ${hocSinhMoi.hoTen} (${hocSinhMoi.maHocSinh}).`,
        ipAddress: input.ipAddress,
    });
    return { lead: updatedLead, hocSinh: hocSinhMoi };
}

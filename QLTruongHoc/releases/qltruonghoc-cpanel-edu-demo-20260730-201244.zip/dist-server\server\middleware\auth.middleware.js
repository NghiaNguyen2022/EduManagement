import { AUTH_COOKIE_NAME } from "../auth/auth.constants.js";
import { getAuthContext } from "../services/auth.service.js";
export async function requireAuth(req, res, next) {
    const token = req.cookies?.[AUTH_COOKIE_NAME];
    const context = await getAuthContext(token);
    if (!context) {
        res.status(401).json({
            ok: false,
            error: "Bạn chưa đăng nhập hoặc phiên đã hết hạn.",
        });
        return;
    }
    req.auth = context;
    next();
}

import { and, count, desc, eq, gte, inArray } from "drizzle-orm";
import { donVi, hocSinh, lopHoc, nguoiDung, traoDoiHocSinh } from "../../drizzle/schema.js";
import { getDb } from "./connection.js";
const now = () => new Date().toISOString().slice(0, 19).replace("T", " ");
function buildFilterConditions(filters = {}) {
    const conditions = [];
    if (filters.hocSinhId) {
        conditions.push(eq(traoDoiHocSinh.hocSinhId, filters.hocSinhId));
    }
    if (filters.lopHocId) {
        conditions.push(eq(traoDoiHocSinh.lopHocId, filters.lopHocId));
    }
    return conditions;
}
function mapRow(row) {
    return {
        traoDoi: {
            id: row.traoDoi.id,
            donViId: row.traoDoi.donViId,
            hocSinhId: row.traoDoi.hocSinhId,
            lopHocId: row.traoDoi.lopHocId,
            nguoiGuiVaiTro: row.traoDoi.nguoiGuiVaiTro,
            kenhLienLac: row.traoDoi.kenhLienLac,
            noiDung: row.traoDoi.noiDung,
            ketQua: row.traoDoi.ketQua,
            nguoiTaoId: row.traoDoi.nguoiTaoId,
            createdAt: row.traoDoi.createdAt,
        },
        hocSinh: {
            id: row.hocSinhId,
            maHocSinh: row.hocSinhMaHocSinh,
            hoTen: row.hocSinhHoTen,
        },
        lopHoc: row.lopHocId
            ? {
                id: row.lopHocId,
                maLop: row.lopHocMaLop ?? "",
                tenLop: row.lopHocTenLop ?? "",
            }
            : null,
        nguoiTao: {
            id: row.nguoiTaoId,
            hoTen: row.nguoiTaoHoTen,
            tenDangNhap: row.nguoiTaoTenDangNhap,
        },
        donVi: row.donViId
            ? {
                id: row.donViId,
                maDonVi: row.donViMaDonVi ?? "",
                tenDonVi: row.donViTenDonVi ?? "",
            }
            : undefined,
    };
}
/** Số trao đổi ghi nhận gần đây trên các lớp chỉ định — dùng cho Portal giáo viên. */
export async function countTraoDoiGanDayTheoLop(lopHocIds, tuNgay) {
    const db = getDb();
    if (lopHocIds.length === 0) {
        return 0;
    }
    const rows = await db
        .select({ total: count() })
        .from(traoDoiHocSinh)
        .where(and(inArray(traoDoiHocSinh.lopHocId, lopHocIds), gte(traoDoiHocSinh.createdAt, tuNgay)));
    return rows[0]?.total ?? 0;
}
export async function listTraoDoiByDonVi(donViId, filters = {}) {
    const db = getDb();
    const conditions = [eq(traoDoiHocSinh.donViId, donViId), ...buildFilterConditions(filters)];
    const rows = await db
        .select({
        traoDoi: traoDoiHocSinh,
        hocSinhId: hocSinh.id,
        hocSinhMaHocSinh: hocSinh.maHocSinh,
        hocSinhHoTen: hocSinh.hoTen,
        lopHocId: lopHoc.id,
        lopHocMaLop: lopHoc.maLop,
        lopHocTenLop: lopHoc.tenLop,
        nguoiTaoId: nguoiDung.id,
        nguoiTaoHoTen: nguoiDung.hoTen,
        nguoiTaoTenDangNhap: nguoiDung.tenDangNhap,
    })
        .from(traoDoiHocSinh)
        .innerJoin(hocSinh, eq(traoDoiHocSinh.hocSinhId, hocSinh.id))
        .innerJoin(nguoiDung, eq(traoDoiHocSinh.nguoiTaoId, nguoiDung.id))
        .leftJoin(lopHoc, eq(traoDoiHocSinh.lopHocId, lopHoc.id))
        .where(and(...conditions))
        .orderBy(desc(traoDoiHocSinh.createdAt));
    return rows.map((row) => mapRow(row));
}
export async function listTraoDoiAllDonVi(filters = {}) {
    const db = getDb();
    const conditions = [eq(donVi.trangThai, "hoat_dong"), ...buildFilterConditions(filters)];
    const rows = await db
        .select({
        traoDoi: traoDoiHocSinh,
        hocSinhId: hocSinh.id,
        hocSinhMaHocSinh: hocSinh.maHocSinh,
        hocSinhHoTen: hocSinh.hoTen,
        lopHocId: lopHoc.id,
        lopHocMaLop: lopHoc.maLop,
        lopHocTenLop: lopHoc.tenLop,
        nguoiTaoId: nguoiDung.id,
        nguoiTaoHoTen: nguoiDung.hoTen,
        nguoiTaoTenDangNhap: nguoiDung.tenDangNhap,
        donViId: donVi.id,
        donViMaDonVi: donVi.maDonVi,
        donViTenDonVi: donVi.tenDonVi,
    })
        .from(traoDoiHocSinh)
        .innerJoin(hocSinh, eq(traoDoiHocSinh.hocSinhId, hocSinh.id))
        .innerJoin(nguoiDung, eq(traoDoiHocSinh.nguoiTaoId, nguoiDung.id))
        .innerJoin(donVi, eq(traoDoiHocSinh.donViId, donVi.id))
        .leftJoin(lopHoc, eq(traoDoiHocSinh.lopHocId, lopHoc.id))
        .where(and(...conditions))
        .orderBy(donVi.tenDonVi, desc(traoDoiHocSinh.createdAt));
    return rows.map((row) => mapRow(row));
}
export async function createTraoDoi(input) {
    const db = getDb();
    const createdAt = now();
    await db.insert(traoDoiHocSinh).values({
        donViId: input.donViId,
        hocSinhId: input.hocSinhId,
        lopHocId: input.lopHocId ?? null,
        nguoiGuiVaiTro: input.nguoiGuiVaiTro,
        kenhLienLac: input.kenhLienLac,
        noiDung: input.noiDung,
        ketQua: input.ketQua ?? null,
        nguoiTaoId: input.nguoiTaoId,
        createdAt,
    });
    const rows = await db
        .select({
        traoDoi: traoDoiHocSinh,
        hocSinhId: hocSinh.id,
        hocSinhMaHocSinh: hocSinh.maHocSinh,
        hocSinhHoTen: hocSinh.hoTen,
        lopHocId: lopHoc.id,
        lopHocMaLop: lopHoc.maLop,
        lopHocTenLop: lopHoc.tenLop,
        nguoiTaoId: nguoiDung.id,
        nguoiTaoHoTen: nguoiDung.hoTen,
        nguoiTaoTenDangNhap: nguoiDung.tenDangNhap,
    })
        .from(traoDoiHocSinh)
        .innerJoin(hocSinh, eq(traoDoiHocSinh.hocSinhId, hocSinh.id))
        .innerJoin(nguoiDung, eq(traoDoiHocSinh.nguoiTaoId, nguoiDung.id))
        .leftJoin(lopHoc, eq(traoDoiHocSinh.lopHocId, lopHoc.id))
        .where(and(eq(traoDoiHocSinh.donViId, input.donViId), eq(traoDoiHocSinh.hocSinhId, input.hocSinhId), eq(traoDoiHocSinh.nguoiTaoId, input.nguoiTaoId), eq(traoDoiHocSinh.createdAt, createdAt)))
        .orderBy(desc(traoDoiHocSinh.id))
        .limit(1);
    return rows[0] ? mapRow(rows[0]) : null;
}
